// ─── Design tokens ────────────────────────────────────────────────────────────
export const tk = {
    green: '#16a34a',
    greenDark: '#15803d',
    greenLight: '#f0fdf4',
    greenBorder: '#bbf7d0',
    white: '#ffffff',
    bg: '#f8faf8',
    gray100: '#f3f4f6',
    gray200: '#e5e7eb',
    gray300: '#d1d5db',
    gray400: '#9ca3af',
    gray500: '#6b7280',
    gray700: '#374151',
    gray900: '#111827',
    red: '#dc2626',
    redLight: '#fef2f2',
    redBorder: '#fecaca',
    amber: '#d97706',
    amberLight: '#fffbeb',
    amberBorder: '#fde68a',
    blue: '#2563eb',
    blueLight: '#eff6ff',
    blueBorder: '#bfdbfe',
}

// ─── Label ────────────────────────────────────────────────────────────────────
export function Label({ children }) {
    return (
        <div style={{
            fontSize: 11, fontWeight: 600, color: tk.gray500,
            marginBottom: 5, letterSpacing: '0.04em', textTransform: 'uppercase',
        }}>
            {children}
        </div>
    )
}

// ─── Input ────────────────────────────────────────────────────────────────────
export function Input({ value, onChange, type = 'text', placeholder = '', disabled }) {
    return (
        <input
            type={type}
            value={value}
            placeholder={placeholder}
            disabled={disabled}
            onChange={e => onChange(e.target.value)}
            style={{
                width: '100%', padding: '8px 11px', borderRadius: 7,
                border: `1.5px solid ${tk.gray200}`, background: tk.white,
                color: tk.gray900, fontSize: 13,
                fontFamily: "'DM Mono', monospace",
                transition: 'border-color 0.15s, box-shadow 0.15s',
            }}
        />
    )
}

// ─── Select ───────────────────────────────────────────────────────────────────
export function Select({ value, onChange, children }) {
    return (
        <select
            value={value}
            onChange={e => onChange(e.target.value)}
            style={{
                width: '100%', padding: '8px 11px', borderRadius: 7,
                border: `1.5px solid ${tk.gray200}`, background: tk.white,
                color: tk.gray900, fontSize: 13,
                fontFamily: "'DM Mono', monospace",
                cursor: 'pointer', transition: 'border-color 0.15s',
            }}
        >
            {children}
        </select>
    )
}

// ─── Field ────────────────────────────────────────────────────────────────────
export function Field({ label, children }) {
    return (
        <div style={{ marginBottom: 12 }}>
            <Label>{label}</Label>
            {children}
        </div>
    )
}

// ─── Row (two-col) ────────────────────────────────────────────────────────────
export function Row({ children }) {
    return (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {children}
        </div>
    )
}

// ─── Btn ─────────────────────────────────────────────────────────────────────
export function Btn({ onClick, disabled, children, variant = 'green', fullWidth, style: extra }) {
    const base = {
        display: 'inline-flex', alignItems: 'center', gap: 7,
        padding: '8px 16px', borderRadius: 7, fontSize: 13, fontWeight: 600,
        fontFamily: "'DM Sans', sans-serif", cursor: 'pointer',
        transition: 'opacity 0.15s',
        width: fullWidth ? '100%' : undefined,
        justifyContent: fullWidth ? 'center' : undefined,
    }
    const variants = {
        green: { background: tk.green, color: '#fff', border: 'none' },
        greenOutline: { background: 'transparent', color: tk.green, border: `1.5px solid ${tk.green}` },
        gray: { background: tk.gray100, color: tk.gray700, border: `1.5px solid ${tk.gray200}` },
        red: { background: tk.red, color: '#fff', border: 'none' },
        redOutline: { background: 'transparent', color: tk.red, border: `1.5px solid ${tk.red}` },
        amber: { background: tk.amber, color: '#fff', border: 'none' },
    }
    return (
        <button onClick={onClick} disabled={disabled}
            style={{ ...base, ...(variants[variant] || variants.green), ...extra }}>
            {children}
        </button>
    )
}

// ─── Spinner ──────────────────────────────────────────────────────────────────
export function Spinner() {
    return (
        <span style={{
            display: 'inline-block', width: 13, height: 13,
            border: '2px solid rgba(255,255,255,0.35)',
            borderTopColor: 'currentColor',
            borderRadius: '50%', animation: 'spin 0.7s linear infinite',
        }} />
    )
}

// ─── MethodPill ───────────────────────────────────────────────────────────────
export function MethodPill({ method }) {
    const map = {
        GET: { bg: tk.greenLight, color: tk.green },
        POST: { bg: tk.blueLight, color: tk.blue },
        PATCH: { bg: tk.amberLight, color: tk.amber },
        DELETE: { bg: tk.redLight, color: tk.red },
    }
    const s = map[method] || map.GET
    return (
        <span style={{
            fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 4,
            background: s.bg, color: s.color,
            fontFamily: "'DM Mono', monospace", letterSpacing: '0.05em',
        }}>
            {method}
        </span>
    )
}

// ─── EndpointRow ──────────────────────────────────────────────────────────────
export function EndpointRow({ method, path }) {
    return (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <MethodPill method={method} />
            <code style={{ fontSize: 11, color: tk.gray400, fontFamily: "'DM Mono', monospace" }}>
                {path}
            </code>
        </div>
    )
}

// ─── Card ─────────────────────────────────────────────────────────────────────
export function Card({ children, style }) {
    return (
        <div style={{
            background: tk.white, borderRadius: 12, padding: '18px 20px',
            border: `1px solid ${tk.gray200}`,
            boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
            ...style,
        }}>
            {children}
        </div>
    )
}

// ─── CardHeader ───────────────────────────────────────────────────────────────
export function CardHeader({ title, method, color }) {
    return (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
            <div style={{
                fontSize: 14, fontWeight: 700,
                color: color || tk.gray900,
            }}>
                {title}
            </div>
            {method && <MethodPill method={method} />}
        </div>
    )
}

// ─── PageHeader ───────────────────────────────────────────────────────────────
export function PageHeader({ title, subtitle }) {
    return (
        <div style={{ marginBottom: 28 }}>
            <h1 style={{ fontSize: 22, fontWeight: 700, color: tk.gray900, marginBottom: 4 }}>
                {title}
            </h1>
            {subtitle && (
                <p style={{ fontSize: 12, color: tk.gray400, fontFamily: "'DM Mono', monospace" }}>
                    {subtitle}
                </p>
            )}
        </div>
    )
}

// ─── ResponseBox ──────────────────────────────────────────────────────────────
export function ResponseBox({ result }) {
    if (!result) return null
    const ok = result.ok
    return (
        <div style={{
            marginTop: 12, borderRadius: 8, padding: '10px 12px',
            background: ok ? tk.greenLight : tk.redLight,
            border: `1px solid ${ok ? tk.greenBorder : tk.redBorder}`,
        }}>
            <div style={{
                fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
                color: ok ? tk.green : tk.red, marginBottom: 5,
                fontFamily: "'DM Mono', monospace",
            }}>
                {ok ? '✓ SUCCESS' : '✗ ERROR'} · HTTP {result.status}
            </div>
            <pre style={{
                fontSize: 10.5, color: tk.gray700,
                fontFamily: "'DM Mono', monospace",
                whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                maxHeight: 200, overflowY: 'auto', lineHeight: 1.6,
                margin: 0,
            }}>
                {JSON.stringify(result.data, null, 2)}
            </pre>
        </div>
    )
}

// ─── Divider ─────────────────────────────────────────────────────────────────
export function Divider({ label }) {
    return (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '16px 0' }}>
            <div style={{ flex: 1, height: 1, background: tk.gray200 }} />
            {label && (
                <span style={{ fontSize: 10, color: tk.gray400, fontFamily: "'DM Mono', monospace", letterSpacing: '0.06em' }}>
                    {label}
                </span>
            )}
            <div style={{ flex: 1, height: 1, background: tk.gray200 }} />
        </div>
    )
}

// ─── TwoColGrid ───────────────────────────────────────────────────────────────
export function TwoColGrid({ children }) {
    return (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, alignItems: 'start' }}>
            {children}
        </div>
    )
}

// ─── Stack ────────────────────────────────────────────────────────────────────
export function Stack({ children, gap = 16 }) {
    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap }}>
            {children}
        </div>
    )
}