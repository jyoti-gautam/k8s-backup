import { useState } from 'react'
import { useAuth } from './AuthContext'
import { apiCall } from './api'
import {
  Card, CardHeader, EndpointRow, Btn,
  Spinner, ResponseBox, PageHeader, TwoColGrid, Stack, tk,
} from './components'

export default function LogoutPage({ setPage }) {
  const { accessToken, refreshToken, user, logout } = useAuth()
  const [confirmed, setConfirmed] = useState(false)
  const [logoutRes,  setLogoutRes]  = useState(null)
  const [logoutBusy, setLogoutBusy] = useState(false)

  async function doLogout() {
    setLogoutBusy(true)
    const r = await apiCall('POST', '/logout', null, accessToken)
    setLogoutRes(r)
    if (r.ok) {
      setTimeout(() => { logout(); setPage('login') }, 1000)
    }
    setLogoutBusy(false)
  }

  return (
    <div style={{ maxWidth: 1080, margin: '0 auto', padding: '32px 24px' }} className="page-enter">
      <PageHeader title="Logout" subtitle="End your session · Clear tokens" />

      <TwoColGrid>
        {/* ── LEFT: Logout action ──────────────────────────────────────── */}
        <Stack gap={16}>

          <Card style={{ border: `1.5px solid ${tk.redBorder}` }}>
            <CardHeader title="Logout Current Session" method="POST" color={tk.red} />
            <EndpointRow method="POST" path="/logout" />

            {/* Info box */}
            <div style={{
              padding: '14px 16px', borderRadius: 8, marginBottom: 16,
              background: tk.redLight, border: `1px solid ${tk.redBorder}`,
              fontSize: 12, color: tk.red, lineHeight: 1.8,
              fontFamily: "'DM Mono', monospace",
            }}>
              Revokes this session and clears <strong>accessToken</strong> +{' '}
              <strong>refreshTokenHash</strong> from the <code>users</code> table.
            </div>

            {!confirmed ? (
              <Btn onClick={() => setConfirmed(true)} variant="redOutline" fullWidth>
                Click to confirm logout
              </Btn>
            ) : (
              <Btn onClick={doLogout} disabled={logoutBusy} variant="red" fullWidth>
                {logoutBusy ? <><Spinner /> Logging out…</> : '⚠ Confirm — End Session →'}
              </Btn>
            )}

            {confirmed && !logoutRes && (
              <p style={{ marginTop: 8, textAlign: 'center', fontSize: 11, color: tk.amber, fontFamily: "'DM Mono', monospace" }}>
                This will end your session immediately.
              </p>
            )}

            <ResponseBox result={logoutRes} />
          </Card>

          {/* User info */}
          {user && (
            <Card>
              <div style={{ fontSize: 14, fontWeight: 700, color: tk.gray900, marginBottom: 12 }}>
                Logged in as
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{
                  width: 40, height: 40, borderRadius: '50%',
                  background: tk.greenLight, border: `2px solid ${tk.greenBorder}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 16, fontWeight: 700, color: tk.green,
                }}>
                  {(user.name || user.email || '?')[0].toUpperCase()}
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: tk.gray900 }}>{user.name}</div>
                  <div style={{ fontSize: 12, color: tk.gray500, fontFamily: "'DM Mono', monospace" }}>{user.email}</div>
                </div>
              </div>
              {user.organizations?.length > 0 && (
                <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {user.organizations.map(o => (
                    <span key={o.organizationId} style={{
                      fontSize: 10, padding: '3px 8px', borderRadius: 4,
                      background: tk.greenLight, color: tk.green,
                      border: `1px solid ${tk.greenBorder}`,
                      fontFamily: "'DM Mono', monospace",
                    }}>
                      org:{o.organizationId} · {o.roleSlug}
                    </span>
                  ))}
                </div>
              )}
            </Card>
          )}
        </Stack>

        {/* ── RIGHT: Token state ───────────────────────────────────────── */}
        <Stack gap={16}>

          <Card>
            <div style={{ fontSize: 14, fontWeight: 700, color: tk.gray900, marginBottom: 14 }}>
              Current Token State
            </div>

            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: tk.gray500, marginBottom: 5, fontFamily: "'DM Mono', monospace", letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                Access Token
              </div>
              <div style={{
                padding: '10px 12px', borderRadius: 8,
                background: tk.greenLight, border: `1px solid ${tk.greenBorder}`,
                wordBreak: 'break-all',
              }}>
                <code style={{ fontSize: 10.5, color: tk.green, fontFamily: "'DM Mono', monospace", lineHeight: 1.6 }}>
                  {accessToken || '—'}
                </code>
              </div>
            </div>

            <div>
              <div style={{ fontSize: 10, fontWeight: 600, color: tk.gray500, marginBottom: 5, fontFamily: "'DM Mono', monospace", letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                Refresh Token
              </div>
              <div style={{
                padding: '10px 12px', borderRadius: 8,
                background: tk.gray100, border: `1px solid ${tk.gray200}`,
                wordBreak: 'break-all',
              }}>
                <code style={{ fontSize: 10.5, color: tk.gray700, fontFamily: "'DM Mono', monospace", lineHeight: 1.6 }}>
                  {refreshToken || '—'}
                </code>
              </div>
            </div>
          </Card>

          <Card style={{ background: tk.gray100, border: `1px solid ${tk.gray200}` }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: tk.gray900, marginBottom: 10 }}>
              What happens on logout
            </div>
            <div style={{ fontSize: 12, color: tk.gray500, lineHeight: 1.9, fontFamily: "'DM Mono', monospace" }}>
              <div>1. Session is revoked in the DB</div>
              <div>2. <code>accessToken</code> cleared from <code>users</code> table</div>
              <div>3. <code>refreshTokenHash</code> cleared from <code>users</code> table</div>
              <div>4. <code>refreshTokenExpiresAt</code> cleared</div>
            </div>
          </Card>
        </Stack>
      </TwoColGrid>
    </div>
  )
}