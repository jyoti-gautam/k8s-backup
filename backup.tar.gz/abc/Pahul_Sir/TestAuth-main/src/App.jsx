import { useState } from 'react'
import { AuthProvider, useAuth } from './AuthContext'
import LoginPage from './LoginPage'
import LogoutPage from './LogoutPage'
import Navbar from './Navbar'
import SessionsPage from './SessionsPage'
import TwoFAPage from './TwofaPage'
import { tk } from './components'

function RequireAuth({ children, setPage }) {
  const { isAuthed } = useAuth()
  if (isAuthed) return children
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      minHeight: 'calc(100vh - 54px)', gap: 16,
    }}>
      <div style={{
        width: 64, height: 64, borderRadius: '50%',
        background: tk.gray100, border: `2px solid ${tk.gray200}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28,
      }}>
        🔒
      </div>
      <p style={{ fontSize: 16, fontWeight: 600, color: tk.gray700 }}>Login required</p>
      <button
        onClick={() => setPage('login')}
        style={{
          padding: '8px 20px', borderRadius: 7, cursor: 'pointer',
          background: 'transparent', border: `1.5px solid ${tk.green}`,
          color: tk.green, fontSize: 13, fontWeight: 600,
        }}
      >
        Go to Login →
      </button>
    </div>
  )
}

function AppInner() {
  const [page, setPage] = useState(() => {
    return localStorage.getItem('accessToken') ? 'sessions' : 'login'
  })

  const renderPage = () => {
    switch (page) {
      case 'login':
        return <LoginPage setPage={setPage} />
      case 'twofa':
        return <RequireAuth setPage={setPage}><TwoFAPage /></RequireAuth>
      case 'sessions':
        return <RequireAuth setPage={setPage}><SessionsPage /></RequireAuth>
      case 'logout':
        return <RequireAuth setPage={setPage}><LogoutPage setPage={setPage} /></RequireAuth>
      default:
        return <LoginPage setPage={setPage} />
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: tk.bg }}>
      <Navbar page={page} setPage={setPage} />
      <main key={page} className="page-enter">
        {renderPage()}
      </main>
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  )
}