import { useState } from 'react'
import { useAuth } from './AuthContext'
import { apiCall, BASE_URL } from './api'
import {
    Card, CardHeader, EndpointRow, Field, Input, Btn,
    Spinner, ResponseBox, PageHeader, TwoColGrid, Stack, Divider, tk,
} from './components'

export default function LoginPage({ setPage }) {
    const { login } = useAuth()

    // — Login fields
    const [email, setEmail] = useState('john@example.com')
    const [pass, setPass] = useState('Password123!')
    const [device, setDevice] = useState('Chrome on macOS')
    const [twoFa, setTwoFa] = useState('')
    const [loginRes, setLoginRes] = useState(null)
    const [loginBusy, setLoginBusy] = useState(false)

    // — Register fields
    const [regName, setRegName] = useState('Test User')
    const [regEmail, setRegEmail] = useState('test@example.com')
    const [regPass, setRegPass] = useState('Password123!')
    const [regPhone, setRegPhone] = useState('')
    const [regOrg, setRegOrg] = useState('1')
    const [regRes, setRegRes] = useState(null)
    const [regBusy, setRegBusy] = useState(false)

    // — Forgot password
    const [forgotEmail, setForgotEmail] = useState('')
    const [forgotRes, setForgotRes] = useState(null)
    const [forgotBusy, setForgotBusy] = useState(false)

    // — Resend verification
    const [verifEmail, setVerifEmail] = useState('')
    const [verifRes, setVerifRes] = useState(null)
    const [verifBusy, setVerifBusy] = useState(false)

    async function doLogin() {
        setLoginBusy(true); setLoginRes(null)
        const body = { email, password: pass }
        if (device) body.deviceName = device
        if (twoFa) body.twoFactorToken = twoFa
        const r = await apiCall('POST', '/login', body)
        setLoginRes(r)
        if (r.ok && r.data?.data?.tokens) {
            login(r.data.data.tokens.accessToken, r.data.data.tokens.refreshToken, r.data.data.user)
            setTimeout(() => setPage('sessions'), 600)
        }
        setLoginBusy(false)
    }

    async function doRegister() {
        setRegBusy(true); setRegRes(null)
        const body = { name: regName, email: regEmail, password: regPass, organizationId: parseInt(regOrg), timezone: 'UTC', locale: 'en' }
        if (regPhone) body.phone = regPhone
        const r = await apiCall('POST', '/register', body)
        setRegRes(r)
        setRegBusy(false)
    }

    async function doForgot() {
        setForgotBusy(true); setForgotRes(null)
        const r = await apiCall('POST', '/password/forgot', { email: forgotEmail })
        setForgotRes(r)
        setForgotBusy(false)
    }

    async function doResendVerif() {
        setVerifBusy(true); setVerifRes(null)
        const r = await apiCall('POST', '/email/resend-verification', { email: verifEmail })
        setVerifRes(r)
        setVerifBusy(false)
    }

    return (
        <div style={{ maxWidth: 1080, margin: '0 auto', padding: '32px 24px' }} className="page-enter">
            <PageHeader
                title="Login & Auth"
                subtitle={`Public routes · ${BASE_URL}`}
            />

            <TwoColGrid>
                {/* ── LEFT: Login + Forgot ─────────────────────────────────────── */}
                <Stack gap={16}>

                    {/* Login */}
                    <Card>
                        <CardHeader title="Login" method="POST" color={tk.green} />
                        <EndpointRow method="POST" path="/login" />

                        <Field label="Email">
                            <Input value={email} onChange={setEmail} type="email" />
                        </Field>
                        <Field label="Password">
                            <Input value={pass} onChange={setPass} type="password" />
                        </Field>
                        <Field label="Device name (optional)">
                            <Input value={device} onChange={setDevice} placeholder="Chrome on macOS" />
                        </Field>
                        <Field label="2FA token (if required)">
                            <Input value={twoFa} onChange={setTwoFa} placeholder="123456" />
                        </Field>

                        <Btn onClick={doLogin} disabled={loginBusy} variant="green" fullWidth>
                            {loginBusy ? <><Spinner /> Logging in…</> : 'Login →'}
                        </Btn>
                        <ResponseBox result={loginRes} />
                    </Card>

                    {/* Forgot Password */}
                    <Card>
                        <CardHeader title="Forgot Password" method="POST" color={tk.amber} />
                        <EndpointRow method="POST" path="/password/forgot" />
                        <Field label="Email">
                            <Input value={forgotEmail} onChange={setForgotEmail} type="email" placeholder="user@example.com" />
                        </Field>
                        <Btn onClick={doForgot} disabled={forgotBusy} variant="amber">
                            {forgotBusy ? <><Spinner /> Sending…</> : 'Send Reset Email'}
                        </Btn>
                        <ResponseBox result={forgotRes} />
                    </Card>

                    {/* Resend Verification */}
                    <Card>
                        <CardHeader title="Resend Verification Email" method="POST" />
                        <EndpointRow method="POST" path="/email/resend-verification" />
                        <Field label="Email">
                            <Input value={verifEmail} onChange={setVerifEmail} type="email" placeholder="user@example.com" />
                        </Field>
                        <Btn onClick={doResendVerif} disabled={verifBusy} variant="gray">
                            {verifBusy ? <><Spinner /> Sending…</> : 'Resend Verification'}
                        </Btn>
                        <ResponseBox result={verifRes} />
                    </Card>
                </Stack>

                {/* ── RIGHT: Register ──────────────────────────────────────────── */}
                <Stack gap={16}>

                    {/* Register */}
                    <Card>
                        <CardHeader title="Register User" method="POST" />
                        <EndpointRow method="POST" path="/register" />

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                            <Field label="Name">
                                <Input value={regName} onChange={setRegName} />
                            </Field>
                            <Field label="Email">
                                <Input value={regEmail} onChange={setRegEmail} type="email" />
                            </Field>
                            <Field label="Password">
                                <Input value={regPass} onChange={setRegPass} type="password" />
                            </Field>
                            <Field label="Phone (optional)">
                                <Input value={regPhone} onChange={setRegPhone} placeholder="+1234567890" />
                            </Field>
                        </div>
                        <Field label="Organization ID">
                            <Input value={regOrg} onChange={setRegOrg} />
                        </Field>

                        <Btn onClick={doRegister} disabled={regBusy} variant="green" fullWidth>
                            {regBusy ? <><Spinner /> Registering…</> : 'Register →'}
                        </Btn>
                        <ResponseBox result={regRes} />
                    </Card>

                    {/* JWT info */}
                    <Card style={{ background: tk.greenLight, border: `1px solid ${tk.greenBorder}` }}>
                        <div style={{ fontSize: 12, color: tk.green, fontFamily: "'DM Mono', monospace", lineHeight: 1.9 }}>
                            <strong>JWT payload after login</strong><br />
                            userId · uuid · email<br />
                            organizations[]: {'{ organizationId, roleId, roleSlug }'}<br />
                            systemRoleId · systemRoleSlug <span style={{ color: tk.greenBorder }}>// if system user</span>
                        </div>
                    </Card>
                </Stack>
            </TwoColGrid>
        </div>
    )
}