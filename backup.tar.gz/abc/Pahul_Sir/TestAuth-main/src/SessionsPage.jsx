import { useState } from 'react'
import { useAuth } from './AuthContext'
import { apiCall } from './api'
import {
    Btn,
    Card, CardHeader, EndpointRow, Field, Input,
    PageHeader,
    ResponseBox,
    Spinner,
    Stack,
    tk,
    TwoColGrid
} from './components'

export default function SessionsPage() {
    const { accessToken, refreshToken, updateAccessToken } = useAuth()

    // Sessions list
    const [sessions, setSessions] = useState([])
    const [sessionsRes, setSessionsRes] = useState(null)
    const [sessionsBusy, setSessionsBusy] = useState(false)

    // Revoke one
    const [revokeId, setRevokeId] = useState('')
    const [revokeRes, setRevokeRes] = useState(null)
    const [revokeBusy, setRevokeBusy] = useState(false)

    // Revoke all
    const [revokeAllRes, setRevokeAllRes] = useState(null)
    const [revokeAllBusy, setRevokeAllBusy] = useState(false)

    // Refresh token
    const [refreshRes, setRefreshRes] = useState(null)
    const [refreshBusy, setRefreshBusy] = useState(false)

    async function doGetSessions() {
        setSessionsBusy(true); setSessionsRes(null)
        const r = await apiCall('GET', '/sessions', null, accessToken)
        setSessionsRes(r)
        if (r.ok && r.data?.data) setSessions(r.data.data)
        setSessionsBusy(false)
    }

    async function doRevoke() {
        if (!revokeId) return
        setRevokeBusy(true); setRevokeRes(null)
        const r = await apiCall('DELETE', `/sessions/${revokeId}`, null, accessToken)
        setRevokeRes(r)
        setRevokeBusy(false)
    }

    async function doRevokeAll() {
        setRevokeAllBusy(true); setRevokeAllRes(null)
        const r = await apiCall('DELETE', '/sessions/all', null, accessToken)
        setRevokeAllRes(r)
        if (r.ok) setSessions([])
        setRevokeAllBusy(false)
    }

    async function doRefreshToken() {
        setRefreshBusy(true); setRefreshRes(null)
        const r = await apiCall('POST', '/refresh-token', { refreshToken })
        setRefreshRes(r)
        if (r.ok && r.data?.data?.accessToken) updateAccessToken(r.data.data.accessToken)
        setRefreshBusy(false)
    }

    return (
        <div style={{ maxWidth: 1080, margin: '0 auto', padding: '32px 24px' }} className="page-enter">
            <PageHeader title="Sessions" subtitle="List active sessions · Revoke · Refresh access token" />

            <TwoColGrid>
                {/* ── LEFT: Sessions list + revoke ─────────────────────────────── */}
                <Stack gap={16}>

                    {/* List sessions */}
                    <Card>
                        <CardHeader title="Active Sessions" method="GET" color={tk.green} />
                        <EndpointRow method="GET" path="/sessions" />
                        <Btn onClick={doGetSessions} disabled={sessionsBusy} variant="green">
                            {sessionsBusy ? <><Spinner /> Loading…</> : 'Fetch Sessions'}
                        </Btn>
                        <ResponseBox result={sessionsRes} />

                        {sessions.length > 0 && (
                            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
                                {sessions.map(s => (
                                    <div key={s.id} style={{
                                        padding: '10px 14px', borderRadius: 8, display: 'flex',
                                        alignItems: 'center', justifyContent: 'space-between',
                                        background: tk.gray100, border: `1px solid ${tk.gray200}`,
                                    }}>
                                        <div>
                                            <div style={{ fontSize: 13, fontWeight: 600, color: tk.gray900 }}>
                                                {s.deviceName}
                                            </div>
                                            <div style={{ fontSize: 11, color: tk.gray500, fontFamily: "'DM Mono', monospace", marginTop: 2 }}>
                                                {s.ipAddress} · {new Date(s.lastActivityAt).toLocaleString()}
                                            </div>
                                        </div>
                                        <span style={{
                                            fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 4,
                                            background: tk.greenLight, color: tk.green, border: `1px solid ${tk.greenBorder}`,
                                            fontFamily: "'DM Mono', monospace",
                                        }}>
                                            #{s.id}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        )}
                    </Card>

                    {/* Revoke single */}
                    <Card>
                        <CardHeader title="Revoke Session" method="DELETE" color={tk.red} />
                        <EndpointRow method="DELETE" path="/sessions/:id" />
                        <Field label="Session ID">
                            <Input value={revokeId} onChange={setRevokeId} type="number" placeholder="Enter session ID" />
                        </Field>
                        <Btn onClick={doRevoke} disabled={revokeBusy || !revokeId} variant="red">
                            {revokeBusy ? <><Spinner /> Revoking…</> : 'Revoke Session'}
                        </Btn>
                        <ResponseBox result={revokeRes} />
                    </Card>

                    {/* Revoke all */}
                    <Card>
                        <CardHeader title="Revoke All Other Sessions" method="DELETE" color={tk.red} />
                        <EndpointRow method="DELETE" path="/sessions/all" />
                        <p style={{ fontSize: 12, color: tk.gray500, marginBottom: 12, lineHeight: 1.6 }}>
                            Revokes all sessions except the current one.
                        </p>
                        <Btn onClick={doRevokeAll} disabled={revokeAllBusy} variant="redOutline">
                            {revokeAllBusy ? <><Spinner /> Revoking all…</> : 'Revoke All Others'}
                        </Btn>
                        <ResponseBox result={revokeAllRes} />
                    </Card>
                </Stack>

                {/* ── RIGHT: Refresh token + token state ───────────────────────── */}
                <Stack gap={16}>

                    {/* Refresh token */}
                    <Card>
                        <CardHeader title="Refresh Access Token" method="POST" />
                        <EndpointRow method="POST" path="/refresh-token" />
                        <p style={{ fontSize: 12, color: tk.gray500, marginBottom: 12, lineHeight: 1.6 }}>
                            Uses the stored refresh token to get a new access token. The context will be updated automatically on success.
                        </p>

                        {/* Show stored refresh token preview */}
                        <div style={{
                            padding: '10px 12px', borderRadius: 8, marginBottom: 12,
                            background: tk.gray100, border: `1px solid ${tk.gray200}`,
                        }}>
                            <div style={{ fontSize: 10, color: tk.gray500, marginBottom: 4, fontFamily: "'DM Mono', monospace", letterSpacing: '0.06em' }}>
                                STORED REFRESH TOKEN
                            </div>
                            <code style={{ fontSize: 10.5, color: tk.gray700, fontFamily: "'DM Mono', monospace", wordBreak: 'break-all', lineHeight: 1.6 }}>
                                {refreshToken ? refreshToken.slice(0, 60) + '…' : '—'}
                            </code>
                        </div>

                        <Btn onClick={doRefreshToken} disabled={refreshBusy || !refreshToken} variant="green">
                            {refreshBusy ? <><Spinner /> Refreshing…</> : '↻ Get New Access Token'}
                        </Btn>
                        <ResponseBox result={refreshRes} />
                    </Card>

                    {/* Current access token */}
                    <Card>
                        <div style={{ fontSize: 14, fontWeight: 700, color: tk.gray900, marginBottom: 12 }}>Current Access Token</div>
                        <div style={{
                            padding: '10px 12px', borderRadius: 8,
                            background: tk.greenLight, border: `1px solid ${tk.greenBorder}`,
                            wordBreak: 'break-all',
                        }}>
                            <code style={{ fontSize: 10.5, color: tk.green, fontFamily: "'DM Mono', monospace", lineHeight: 1.6 }}>
                                {accessToken || '—'}
                            </code>
                        </div>
                    </Card>

                    {/* How sessions work */}
                    <Card style={{ background: tk.gray100, border: `1px solid ${tk.gray200}` }}>
                        <div style={{ fontSize: 14, fontWeight: 700, color: tk.gray900, marginBottom: 10 }}>How sessions work</div>
                        <div style={{ fontSize: 12, color: tk.gray500, lineHeight: 1.9, fontFamily: "'DM Mono', monospace" }}>
                            <div>🔑 <strong style={{ color: tk.gray700 }}>Login</strong> — creates a session + saves tokens to DB</div>
                            <div>🗑 <strong style={{ color: tk.gray700 }}>Revoke one</strong> — ends a specific session by ID</div>
                            <div>🧹 <strong style={{ color: tk.gray700 }}>Revoke all</strong> — ends all except the current session</div>
                            <div>♻ <strong style={{ color: tk.gray700 }}>Refresh</strong> — swap refresh token for a new access token</div>
                        </div>
                    </Card>
                </Stack>
            </TwoColGrid>
        </div>
    )
}