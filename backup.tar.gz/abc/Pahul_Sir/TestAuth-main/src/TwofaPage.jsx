import { useState } from 'react'
import { useAuth } from './AuthContext'
import { apiCall } from './api'
import {
    Btn,
    Card, CardHeader, EndpointRow, Field, Input,
    PageHeader,
    ResponseBox,
    Select,
    Spinner,
    Stack,
    tk,
    TwoColGrid
} from './components'

// Step tracker
function Steps({ step }) {
    const steps = ['Setup', 'Enable', 'Verify', 'Done']
    return (
        <div style={{
            display: 'flex', alignItems: 'center',
            background: tk.white, border: `1px solid ${tk.gray200}`,
            borderRadius: 10, padding: '14px 20px', marginBottom: 24,
            boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
        }}>
            {steps.map((label, i) => {
                const n = i + 1
                const done = step > n
                const active = step === n
                return (
                    <div key={n} style={{ display: 'flex', alignItems: 'center', flex: n < 4 ? 1 : 0 }}>
                        {/* Circle */}
                        <div style={{
                            width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontSize: 11, fontWeight: 700,
                            background: done ? tk.green : active ? tk.greenLight : tk.gray100,
                            color: done ? '#fff' : active ? tk.green : tk.gray400,
                            border: `2px solid ${done ? tk.green : active ? tk.green : tk.gray200}`,
                            transition: 'all 0.25s',
                        }}>
                            {done ? '✓' : n}
                        </div>
                        {/* Label */}
                        <span style={{
                            marginLeft: 7, fontSize: 12, fontWeight: active ? 600 : 400,
                            color: done ? tk.gray400 : active ? tk.green : tk.gray300,
                            whiteSpace: 'nowrap',
                        }}>
                            {label}
                        </span>
                        {/* Connector */}
                        {n < 4 && (
                            <div style={{
                                flex: 1, height: 1, margin: '0 12px',
                                background: done ? tk.green : tk.gray200,
                                transition: 'background 0.3s',
                            }} />
                        )}
                    </div>
                )
            })}
        </div>
    )
}

export default function TwoFAPage() {
    const { accessToken } = useAuth()
    const [step, setStep] = useState(1)

    // Setup
    const [method, setMethod] = useState('totp')
    const [qrCode, setQrCode] = useState(null)
    const [secret, setSecret] = useState(null)
    const [setupRes, setSetupRes] = useState(null)
    const [setupBusy, setSetupBusy] = useState(false)

    // Enable
    const [enableTok, setEnableTok] = useState('')
    const [backupCodes, setBackupCodes] = useState([])
    const [enableRes, setEnableRes] = useState(null)
    const [enableBusy, setEnableBusy] = useState(false)

    // Verify
    const [verifyTok, setVerifyTok] = useState('')
    const [verifyRes, setVerifyRes] = useState(null)
    const [verifyBusy, setVerifyBusy] = useState(false)

    // Disable
    const [disablePass, setDisablePass] = useState('')
    const [disableRes, setDisableRes] = useState(null)
    const [disableBusy, setDisableBusy] = useState(false)

    // Regen backup codes
    const [regenPass, setRegenPass] = useState('')
    const [regenRes, setRegenRes] = useState(null)
    const [regenBusy, setRegenBusy] = useState(false)

    async function doSetup() {
        setSetupBusy(true); setSetupRes(null)
        const r = await apiCall('POST', '/2fa/setup', { method }, accessToken)
        setSetupRes(r)
        if (r.ok && r.data?.data) {
            setQrCode(r.data.data.qrCode || null)
            setSecret(r.data.data.secret || null)
            setStep(2)
        }
        setSetupBusy(false)
    }

    async function doEnable() {
        setEnableBusy(true); setEnableRes(null)
        const r = await apiCall('POST', '/2fa/enable', { token: enableTok }, accessToken)
        setEnableRes(r)
        if (r.ok) {
            if (r.data?.data?.backupCodes) setBackupCodes(r.data.data.backupCodes)
            setStep(3)
        }
        setEnableBusy(false)
    }

    async function doVerify() {
        setVerifyBusy(true); setVerifyRes(null)
        const r = await apiCall('POST', '/2fa/verify', { token: verifyTok }, accessToken)
        setVerifyRes(r)
        if (r.ok) setStep(4)
        setVerifyBusy(false)
    }

    async function doDisable() {
        setDisableBusy(true); setDisableRes(null)
        const r = await apiCall('POST', '/2fa/disable', { password: disablePass }, accessToken)
        setDisableRes(r)
        if (r.ok) { setStep(1); setQrCode(null); setSecret(null); setBackupCodes([]) }
        setDisableBusy(false)
    }

    async function doRegen() {
        setRegenBusy(true); setRegenRes(null)
        const r = await apiCall('POST', '/2fa/backup-codes/regenerate', { password: regenPass }, accessToken)
        setRegenRes(r)
        if (r.ok && r.data?.data?.backupCodes) setBackupCodes(r.data.data.backupCodes)
        setRegenBusy(false)
    }

    return (
        <div style={{ maxWidth: 1080, margin: '0 auto', padding: '32px 24px' }} className="page-enter">
            <PageHeader title="Two-Factor Auth" subtitle="Setup → Enable → Verify · Disable · Backup codes" />

            <Steps step={step} />

            <TwoColGrid>
                {/* ── LEFT: Setup flow ─────────────────────────────────────────── */}
                <Stack gap={16}>

                    {/* Step 1: Setup */}
                    <Card style={{ border: step >= 1 ? `1.5px solid ${tk.green}` : undefined, opacity: 1 }}>
                        <CardHeader title="Step 1 — Setup 2FA" method="POST" color={tk.green} />
                        <EndpointRow method="POST" path="/2fa/setup" />
                        <Field label="Method">
                            <Select value={method} onChange={setMethod}>
                                <option value="totp">TOTP — Authenticator App</option>
                                <option value="email">Email</option>
                                <option value="sms">SMS</option>
                            </Select>
                        </Field>
                        <Btn onClick={doSetup} disabled={setupBusy} variant="green">
                            {setupBusy ? <><Spinner /> Setting up…</> : 'Setup 2FA →'}
                        </Btn>
                        <ResponseBox result={setupRes} />

                        {qrCode && (
                            <div style={{
                                marginTop: 14, padding: 16, borderRadius: 10, textAlign: 'center',
                                background: tk.gray100, border: `1px solid ${tk.gray200}`,
                            }}>
                                <p style={{ fontSize: 10, color: tk.gray500, marginBottom: 10, fontFamily: "'DM Mono', monospace", letterSpacing: '0.08em' }}>
                                    SCAN WITH AUTHENTICATOR APP
                                </p>
                                <img src={qrCode} alt="QR Code" style={{ maxWidth: 150, margin: '0 auto', border: `2px solid ${tk.green}`, borderRadius: 8 }} />
                                {secret && (
                                    <p style={{ marginTop: 10, fontSize: 11, color: tk.gray500, fontFamily: "'DM Mono', monospace" }}>
                                        Secret: <span style={{ color: tk.green }}>{secret}</span>
                                    </p>
                                )}
                            </div>
                        )}
                    </Card>

                    {/* Step 2: Enable */}
                    <Card style={{ opacity: step < 2 ? 0.45 : 1, border: step === 2 ? `1.5px solid ${tk.green}` : undefined }}>
                        <CardHeader title="Step 2 — Enable 2FA" method="POST" color={step >= 2 ? tk.green : tk.gray400} />
                        <EndpointRow method="POST" path="/2fa/enable" />
                        <Field label="Token from authenticator app">
                            <Input value={enableTok} onChange={setEnableTok} placeholder="123456" disabled={step < 2} />
                        </Field>
                        <Btn onClick={doEnable} disabled={enableBusy || step < 2} variant="green">
                            {enableBusy ? <><Spinner /> Enabling…</> : 'Enable 2FA →'}
                        </Btn>
                        <ResponseBox result={enableRes} />

                        {backupCodes.length > 0 && (
                            <div style={{
                                marginTop: 12, padding: 12, borderRadius: 8,
                                background: tk.amberLight, border: `1px solid ${tk.amberBorder}`,
                            }}>
                                <p style={{ fontSize: 10, fontWeight: 700, color: tk.amber, marginBottom: 8, fontFamily: "'DM Mono', monospace", letterSpacing: '0.06em' }}>
                                    ⚠ SAVE THESE BACKUP CODES
                                </p>
                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                                    {backupCodes.map((c, i) => (
                                        <code key={i} style={{
                                            background: tk.white, border: `1px solid ${tk.amberBorder}`,
                                            borderRadius: 5, padding: '2px 8px', fontSize: 10,
                                            color: tk.amber, fontFamily: "'DM Mono', monospace",
                                        }}>{c}</code>
                                    ))}
                                </div>
                            </div>
                        )}
                    </Card>

                    {/* Step 3: Verify */}
                    <Card style={{ opacity: step < 3 ? 0.45 : 1, border: step === 3 ? `1.5px solid ${tk.green}` : undefined }}>
                        <CardHeader title="Step 3 — Verify Token" method="POST" color={step >= 3 ? tk.green : tk.gray400} />
                        <EndpointRow method="POST" path="/2fa/verify" />
                        <Field label="Token">
                            <Input value={verifyTok} onChange={setVerifyTok} placeholder="123456" disabled={step < 3} />
                        </Field>
                        <Btn onClick={doVerify} disabled={verifyBusy || step < 3} variant="green">
                            {verifyBusy ? <><Spinner /> Verifying…</> : 'Verify Token →'}
                        </Btn>
                        <ResponseBox result={verifyRes} />

                        {step === 4 && (
                            <div style={{
                                marginTop: 12, padding: 12, borderRadius: 8,
                                background: tk.greenLight, border: `1px solid ${tk.greenBorder}`,
                                textAlign: 'center', fontSize: 13, color: tk.green, fontWeight: 600,
                            }}>
                                ✓ 2FA is fully enabled and verified
                            </div>
                        )}
                    </Card>
                </Stack>

                {/* ── RIGHT: Disable + Regen ───────────────────────────────────── */}
                <Stack gap={16}>

                    {/* Disable 2FA */}
                    <Card>
                        <CardHeader title="Disable 2FA" method="POST" color={tk.red} />
                        <EndpointRow method="POST" path="/2fa/disable" />
                        <Field label="Confirm with your password">
                            <Input value={disablePass} onChange={setDisablePass} type="password" placeholder="Password123!" />
                        </Field>
                        <Btn onClick={doDisable} disabled={disableBusy} variant="red">
                            {disableBusy ? <><Spinner /> Disabling…</> : 'Disable 2FA'}
                        </Btn>
                        <ResponseBox result={disableRes} />
                    </Card>

                    {/* Regenerate backup codes */}
                    <Card>
                        <CardHeader title="Regenerate Backup Codes" method="POST" color={tk.amber} />
                        <EndpointRow method="POST" path="/2fa/backup-codes/regenerate" />
                        <Field label="Confirm with your password">
                            <Input value={regenPass} onChange={setRegenPass} type="password" placeholder="Password123!" />
                        </Field>
                        <Btn onClick={doRegen} disabled={regenBusy} variant="amber">
                            {regenBusy ? <><Spinner /> Regenerating…</> : 'Regenerate Backup Codes'}
                        </Btn>
                        <ResponseBox result={regenRes} />
                    </Card>

                    {/* Info */}
                    <Card style={{ background: tk.gray100, border: `1px solid ${tk.gray200}` }}>
                        <p style={{ fontSize: 12, color: tk.gray500, lineHeight: 1.8, fontFamily: "'DM Mono', monospace" }}>
                            <strong style={{ color: tk.gray700 }}>Setup flow</strong><br />
                            1. POST /2fa/setup → get QR code<br />
                            2. Scan QR in authenticator app<br />
                            3. POST /2fa/enable with 6-digit code<br />
                            4. POST /2fa/verify to confirm it works<br /><br />
                            <strong style={{ color: tk.gray700 }}>On next login</strong><br />
                            Include <code>twoFactorToken</code> in the login body
                        </p>
                    </Card>
                </Stack>
            </TwoColGrid>
        </div>
    )
}