import { useAuth } from './AuthContext'
import { tk } from './components'

const NAV_LINKS = [
    { id: 'login', label: 'Login', auth: false },
    { id: 'twofa', label: '2FA', auth: true },
    { id: 'sessions', label: 'Sessions', auth: true },
    { id: 'logout', label: 'Logout', auth: true },
]

export default function Navbar({ page, setPage }) {
    const { isAuthed, user } = useAuth()

    return (
        <nav style={{
            position: 'sticky', top: 0, zIndex: 100,
            background: tk.white,
            borderBottom: `1px solid ${tk.gray200}`,
            display: 'flex', alignItems: 'center',
            padding: '0 32px', height: 54,
            boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
        }}>

            {/* Brand */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginRight: 32 }}>
                <div style={{
                    width: 30, height: 30, borderRadius: 8,
                    background: tk.green,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                        <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                    </svg>
                </div>
                <span style={{ fontSize: 14, fontWeight: 700, color: tk.gray900, letterSpacing: '-0.01em' }}>
                    AuthKit <span style={{ fontWeight: 400, color: tk.gray400 }}>tester</span>
                </span>
            </div>

            {/* Separator */}
            <div style={{ width: 1, height: 22, background: tk.gray200, marginRight: 28 }} />

            {/* Nav links */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                {NAV_LINKS.map(link => {
                    const active = page === link.id
                    const locked = link.auth && !isAuthed
                    return (
                        <button
                            key={link.id}
                            onClick={() => !locked && setPage(link.id)}
                            style={{
                                padding: '6px 14px', borderRadius: 7, border: 'none',
                                background: active ? tk.greenLight : 'transparent',
                                color: active ? tk.green : locked ? tk.gray300 : tk.gray500,
                                fontSize: 13, fontWeight: active ? 600 : 400,
                                cursor: locked ? 'not-allowed' : 'pointer',
                                transition: 'all 0.15s',
                                display: 'flex', alignItems: 'center', gap: 5,
                            }}
                        >
                            {link.label}
                            {locked && (
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
                                </svg>
                            )}
                        </button>
                    )
                })}
            </div>

            {/* Right: status */}
            <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 12 }}>
                {isAuthed && user && (
                    <span style={{ fontSize: 12, color: tk.gray500, fontFamily: "'DM Mono', monospace" }}>
                        {user.name || user.email}
                    </span>
                )}
                <div style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    padding: '4px 12px', borderRadius: 100,
                    background: isAuthed ? tk.greenLight : tk.gray100,
                    border: `1px solid ${isAuthed ? tk.greenBorder : tk.gray200}`,
                }}>
                    <span style={{
                        width: 6, height: 6, borderRadius: '50%',
                        background: isAuthed ? tk.green : tk.gray400,
                    }} />
                    <span style={{
                        fontSize: 10, fontWeight: 700, letterSpacing: '0.08em',
                        color: isAuthed ? tk.green : tk.gray400,
                        fontFamily: "'DM Mono', monospace",
                    }}>
                        {isAuthed ? 'AUTHED' : 'GUEST'}
                    </span>
                </div>
            </div>
        </nav>
    )
}