import { createContext, useContext, useState } from 'react'

const AuthContext = createContext(null)

export function useAuth() {
    return useContext(AuthContext)
}

function loadFromStorage() {
    try {
        return {
            accessToken: localStorage.getItem('accessToken') || '',
            refreshToken: localStorage.getItem('refreshToken') || '',
            user: JSON.parse(localStorage.getItem('user') || 'null'),
        }
    } catch {
        return { accessToken: '', refreshToken: '', user: null }
    }
}

export function AuthProvider({ children }) {
    const stored = loadFromStorage()
    const [accessToken, setAccessToken] = useState(stored.accessToken)
    const [refreshToken, setRefreshToken] = useState(stored.refreshToken)
    const [user, setUser] = useState(stored.user)

    function login(at, rt, u) {
        setAccessToken(at)
        setRefreshToken(rt)
        setUser(u)
        localStorage.setItem('accessToken', at)
        localStorage.setItem('refreshToken', rt)
        localStorage.setItem('user', JSON.stringify(u))
    }

    function logout() {
        setAccessToken('')
        setRefreshToken('')
        setUser(null)
        localStorage.removeItem('accessToken')
        localStorage.removeItem('refreshToken')
        localStorage.removeItem('user')
    }

    function updateAccessToken(at) {
        setAccessToken(at)
        localStorage.setItem('accessToken', at)
    }

    return (
        <AuthContext.Provider
            value={{
                accessToken,
                refreshToken,
                user,
                isAuthed: !!accessToken,
                login,
                logout,
                updateAccessToken,
            }}
        >
            {children}
        </AuthContext.Provider>
    )
}