import { useState } from "react";
import { apiCall } from "./api";
import { Btn, Card, CardTitle, Field, Input, MethodBadge, PageHeader, ResponseBox, Select, Spinner } from "./components";

export default function HomePage({ token, refreshToken, user, onTokenRefresh }) {
    const displayUser = user;

    // Profile
    const [profileResult, setProfileResult] = useState(null);
    const [profile, setProfile] = useState(null);

    // Update Profile
    const [upName, setUpName] = useState("");
    const [upPhone, setUpPhone] = useState("");
    const [upTz, setUpTz] = useState("UTC");
    const [upLocale, setUpLocale] = useState("en");
    const [updateResult, setUpdateResult] = useState(null);

    // Change Password
    const [curPass, setCurPass] = useState("");
    const [newPass, setNewPass] = useState("");
    const [passResult, setPassResult] = useState(null);

    // Sessions
    const [sessions, setSessions] = useState([]);
    const [sessionResult, setSessionResult] = useState(null);
    const [revokeId, setRevokeId] = useState("");

    // Admin: Create User
    const [adminName, setAdminName] = useState("");
    const [adminEmail, setAdminEmail] = useState("");
    const [adminPass, setAdminPass] = useState("Password123!");
    const [adminOrg, setAdminOrg] = useState("1");
    const [adminRole, setAdminRole] = useState("customer");
    const [adminCreateResult, setAdminCreateResult] = useState(null);

    // Admin: Status & Unlock
    const [statusUid, setStatusUid] = useState("");
    const [statusVal, setStatusVal] = useState("active");
    const [statusResult, setStatusResult] = useState(null);

    // Refresh Token
    const [refreshResult, setRefreshResult] = useState(null);

    const [loads, setLoads] = useState({});
    const setLoad = (k, v) => setLoads((p) => ({ ...p, [k]: v }));

    async function doGetProfile() {
        setLoad("profile", true);
        const r = await apiCall("GET", "/profile", null, token);
        setProfileResult(r);
        if (r.ok && r.data?.data) setProfile(r.data.data);
        setLoad("profile", false);
    }

    async function doUpdateProfile() {
        setLoad("update", true);
        const body = {};
        if (upName) body.name = upName;
        if (upPhone) body.phone = upPhone;
        body.timezone = upTz;
        body.locale = upLocale;
        const r = await apiCall("PATCH", "/profile", body, token);
        setUpdateResult(r);
        setLoad("update", false);
    }

    async function doChangePass() {
        setLoad("pass", true);
        const r = await apiCall("POST", "/password/change", { currentPassword: curPass, newPassword: newPass }, token);
        setPassResult(r);
        setLoad("pass", false);
    }

    async function doGetSessions() {
        setLoad("sessions", true);
        const r = await apiCall("GET", "/sessions", null, token);
        setSessionResult(r);
        if (r.ok && r.data?.data) setSessions(r.data.data);
        setLoad("sessions", false);
    }

    async function doRevokeSession() {
        if (!revokeId) return;
        setLoad("revoke", true);
        const r = await apiCall("DELETE", `/sessions/${revokeId}`, null, token);
        setSessionResult(r);
        setLoad("revoke", false);
    }

    async function doRevokeAll() {
        setLoad("revokeAll", true);
        const r = await apiCall("DELETE", "/sessions/all", null, token);
        setSessionResult(r);
        setLoad("revokeAll", false);
    }

    async function doAdminCreate() {
        setLoad("adminCreate", true);
        const r = await apiCall(
            "POST", "/admin/create-user",
            { name: adminName, email: adminEmail, password: adminPass, organizationId: parseInt(adminOrg), organizationRoleSlug: adminRole, timezone: "UTC", locale: "en" },
            token
        );
        setAdminCreateResult(r);
        setLoad("adminCreate", false);
    }

    async function doUpdateStatus() {
        if (!statusUid) return;
        setLoad("status", true);
        const r = await apiCall("PATCH", `/admin/users/${statusUid}/status`, { status: statusVal }, token);
        setStatusResult(r);
        setLoad("status", false);
    }

    async function doUnlockUser() {
        if (!statusUid) return;
        setLoad("unlock", true);
        const r = await apiCall("PATCH", `/admin/users/${statusUid}/unlock`, null, token);
        setStatusResult(r);
        setLoad("unlock", false);
    }

    async function doRefreshToken() {
        setLoad("refresh", true);
        const r = await apiCall("POST", "/refresh-token", { refreshToken });
        setRefreshResult(r);
        if (r.ok && r.data?.data?.accessToken) onTokenRefresh(r.data.data.accessToken);
        setLoad("refresh", false);
    }

    const activeUser = profile || displayUser;

    return (
        <div className="min-h-screen p-8" style={{ maxWidth: 1120, margin: "0 auto" }}>
            <PageHeader title="Home Dashboard" accent="#22d3ee" subtitle="Protected routes · Requires Bearer token" />

            {/* Stats */}
            {activeUser && (
                <div className="grid grid-cols-4 gap-3 mb-6">
                    {[
                        { label: "Status", value: activeUser.status || "—", color: "#10b981" },
                        { label: "2FA Enabled", value: activeUser.has2FA ? "YES" : "NO", color: activeUser.has2FA ? "#10b981" : "#f43f5e" },
                        { label: "Email Verified", value: activeUser.emailVerified ? "YES" : "NO", color: activeUser.emailVerified ? "#10b981" : "#f59e0b" },
                        { label: "Orgs", value: activeUser.organizations?.length ?? "—", color: "#22d3ee" },
                    ].map((s) => (
                        <div key={s.label} className="rounded-xl p-4" style={{ background: "#0b1120", border: "1px solid #1e293b" }}>
                            <div style={{ fontSize: 9, letterSpacing: "0.12em", textTransform: "uppercase", color: "#475569", marginBottom: 5, fontFamily: "'IBM Plex Mono',monospace" }}>{s.label}</div>
                            <div style={{ fontFamily: "'Unbounded', sans-serif", fontSize: 14, fontWeight: 700, color: s.color }}>{String(s.value).toUpperCase()}</div>
                        </div>
                    ))}
                </div>
            )}

            <div className="grid grid-cols-2 gap-5">
                {/* ── LEFT ── */}
                <div className="flex flex-col gap-5">

                    {/* Get Profile */}
                    <Card>
                        <div className="flex items-center justify-between mb-3">
                            <CardTitle color="#10b981">Get Profile</CardTitle>
                            <MethodBadge method="GET" />
                        </div>
                        <p style={{ fontSize: 11, color: "#475569", marginBottom: 12, fontFamily: "'IBM Plex Mono',monospace" }}>GET /profile</p>
                        <Btn onClick={doGetProfile} disabled={loads.profile} variant="primary" size="sm">
                            {loads.profile ? <><Spinner /> Fetching...</> : "Fetch Profile"}
                        </Btn>
                        <ResponseBox result={profileResult} />
                    </Card>

                    {/* Update Profile */}
                    <Card>
                        <div className="flex items-center justify-between mb-3">
                            <CardTitle color="#f59e0b">Update Profile</CardTitle>
                            <MethodBadge method="PATCH" />
                        </div>
                        <p style={{ fontSize: 11, color: "#475569", marginBottom: 12, fontFamily: "'IBM Plex Mono',monospace" }}>PATCH /profile</p>
                        <div className="grid grid-cols-2 gap-3">
                            <Field label="Name"><Input value={upName} onChange={setUpName} placeholder="John Updated" /></Field>
                            <Field label="Phone"><Input value={upPhone} onChange={setUpPhone} placeholder="+9876543210" /></Field>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <Field label="Timezone"><Input value={upTz} onChange={setUpTz} /></Field>
                            <Field label="Locale"><Input value={upLocale} onChange={setUpLocale} /></Field>
                        </div>
                        <Btn onClick={doUpdateProfile} disabled={loads.update} variant="amber" size="sm">
                            {loads.update ? <><Spinner /> Updating...</> : "Update Profile →"}
                        </Btn>
                        <ResponseBox result={updateResult} />
                    </Card>

                    {/* Change Password */}
                    <Card>
                        <div className="flex items-center justify-between mb-3">
                            <CardTitle color="#f43f5e">Change Password</CardTitle>
                            <MethodBadge method="POST" />
                        </div>
                        <p style={{ fontSize: 11, color: "#475569", marginBottom: 12, fontFamily: "'IBM Plex Mono',monospace" }}>POST /password/change</p>
                        <Field label="Current Password"><Input value={curPass} onChange={setCurPass} type="password" placeholder="Password123!" /></Field>
                        <Field label="New Password"><Input value={newPass} onChange={setNewPass} type="password" placeholder="NewPassword123!" /></Field>
                        <Btn onClick={doChangePass} disabled={loads.pass} variant="danger" size="sm">
                            {loads.pass ? <><Spinner /> Changing...</> : "Change Password"}
                        </Btn>
                        <ResponseBox result={passResult} />
                    </Card>

                    {/* Refresh Token */}
                    <Card>
                        <div className="flex items-center justify-between mb-3">
                            <CardTitle color="#22d3ee">Refresh Access Token</CardTitle>
                            <MethodBadge method="POST" />
                        </div>
                        <p style={{ fontSize: 11, color: "#475569", marginBottom: 10, fontFamily: "'IBM Plex Mono',monospace" }}>POST /refresh-token</p>
                        <div className="mb-3 p-2 rounded-lg" style={{ background: "#0f172a", border: "1px solid #1e293b" }}>
                            <p style={{ fontSize: 10, color: "#475569", fontFamily: "'IBM Plex Mono',monospace", wordBreak: "break-all" }}>
                                Stored: <span style={{ color: "#22d3ee" }}>{refreshToken ? refreshToken.slice(0, 40) + "..." : "—"}</span>
                            </p>
                        </div>
                        <Btn onClick={doRefreshToken} disabled={loads.refresh} variant="cyan" size="sm">
                            {loads.refresh ? <><Spinner /> Refreshing...</> : "↻ Get New Access Token"}
                        </Btn>
                        <ResponseBox result={refreshResult} />
                    </Card>
                </div>

                {/* ── RIGHT ── */}
                <div className="flex flex-col gap-5">

                    {/* Sessions */}
                    <Card>
                        <div className="flex items-center justify-between mb-3">
                            <CardTitle color="#22d3ee">Sessions</CardTitle>
                            <MethodBadge method="GET" />
                        </div>
                        <p style={{ fontSize: 11, color: "#475569", marginBottom: 12, fontFamily: "'IBM Plex Mono',monospace" }}>GET /sessions</p>
                        <Btn onClick={doGetSessions} disabled={loads.sessions} variant="cyan" size="sm" className="mb-3">
                            {loads.sessions ? <><Spinner /> Loading...</> : "Fetch Sessions"}
                        </Btn>

                        {sessions.length > 0 && (
                            <div className="mb-3 flex flex-col gap-2">
                                {sessions.map((s) => (
                                    <div key={s.id} className="rounded-lg p-3 flex items-center justify-between" style={{ background: "#0f172a", border: "1px solid #1e293b" }}>
                                        <div>
                                            <p style={{ fontSize: 11, fontWeight: 600, color: "#e2e8f0", fontFamily: "'IBM Plex Mono',monospace" }}>📱 {s.deviceName}</p>
                                            <p style={{ fontSize: 10, color: "#475569", fontFamily: "'IBM Plex Mono',monospace" }}>{s.ipAddress} · {new Date(s.lastActivityAt).toLocaleString()}</p>
                                        </div>
                                        <span style={{ fontSize: 9, color: "#10b981", background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)", borderRadius: 4, padding: "2px 8px", fontFamily: "'IBM Plex Mono',monospace" }}>#{s.id}</span>
                                    </div>
                                ))}
                            </div>
                        )}

                        <div style={{ borderTop: "1px solid #1e293b", paddingTop: 12 }}>
                            <Field label="Revoke Session by ID">
                                <Input value={revokeId} onChange={setRevokeId} type="number" placeholder="Session ID" />
                            </Field>
                            <div className="flex gap-2">
                                <Btn onClick={doRevokeSession} disabled={loads.revoke} variant="danger" size="sm">
                                    {loads.revoke ? <><Spinner /></> : "DELETE /sessions/:id"}
                                </Btn>
                                <Btn onClick={doRevokeAll} disabled={loads.revokeAll} variant="ghost" size="sm">
                                    {loads.revokeAll ? <><Spinner /></> : "Revoke All Others"}
                                </Btn>
                            </div>
                            <ResponseBox result={sessionResult} />
                        </div>
                    </Card>

                    {/* Admin: Create User */}
                    <Card>
                        <div className="flex items-center justify-between mb-3">
                            <CardTitle color="#f59e0b">Admin: Create User</CardTitle>
                            <MethodBadge method="POST" />
                        </div>
                        <p style={{ fontSize: 11, color: "#475569", marginBottom: 12, fontFamily: "'IBM Plex Mono',monospace" }}>POST /admin/create-user</p>
                        <div className="grid grid-cols-2 gap-3">
                            <Field label="Name"><Input value={adminName} onChange={setAdminName} placeholder="New User" /></Field>
                            <Field label="Email"><Input value={adminEmail} onChange={setAdminEmail} type="email" placeholder="user@example.com" /></Field>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <Field label="Password"><Input value={adminPass} onChange={setAdminPass} type="password" /></Field>
                            <Field label="Org ID"><Input value={adminOrg} onChange={setAdminOrg} /></Field>
                        </div>
                        <Field label="organizationRoleSlug">
                            <Select value={adminRole} onChange={setAdminRole}>
                                {["customer", "project-user", "admin", "owner", "reseller"].map((r) => (
                                    <option key={r} value={r}>{r}</option>
                                ))}
                            </Select>
                        </Field>
                        <Btn onClick={doAdminCreate} disabled={loads.adminCreate} variant="primary" size="sm">
                            {loads.adminCreate ? <><Spinner /> Creating...</> : "Create User →"}
                        </Btn>
                        <ResponseBox result={adminCreateResult} />
                    </Card>

                    {/* Admin: Status & Unlock */}
                    <Card>
                        <div className="flex items-center justify-between mb-3">
                            <CardTitle color="#f43f5e">Admin: Status & Unlock</CardTitle>
                            <MethodBadge method="PATCH" />
                        </div>
                        <p style={{ fontSize: 11, color: "#475569", marginBottom: 12, fontFamily: "'IBM Plex Mono',monospace" }}>
                            PATCH /admin/users/:id/status · /unlock
                        </p>
                        <div className="grid grid-cols-2 gap-3">
                            <Field label="User ID"><Input value={statusUid} onChange={setStatusUid} type="number" placeholder="5" /></Field>
                            <Field label="New Status">
                                <Select value={statusVal} onChange={setStatusVal}>
                                    {["active", "blocked", "deleted", "pending_verification"].map((s) => (
                                        <option key={s} value={s}>{s}</option>
                                    ))}
                                </Select>
                            </Field>
                        </div>
                        <div className="flex gap-2">
                            <Btn onClick={doUpdateStatus} disabled={loads.status} variant="amber" size="sm">
                                {loads.status ? <><Spinner /></> : "Update Status"}
                            </Btn>
                            <Btn onClick={doUnlockUser} disabled={loads.unlock} variant="cyan" size="sm">
                                {loads.unlock ? <><Spinner /></> : "Unlock User"}
                            </Btn>
                        </div>
                        <ResponseBox result={statusResult} />
                    </Card>
                </div>
            </div>
        </div>
    );
}