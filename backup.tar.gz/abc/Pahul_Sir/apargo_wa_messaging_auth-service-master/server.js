import dotenv from "dotenv";
import app from "./src/app.js";
import { connectDB } from "./src/config/db.js";
import { initModels } from "./src/models/index.js";
import EmailService from "./src/utils/EmailService.js";

dotenv.config();

const PORT = process.env.PORT || 5000;

const startServer = async () => {
    try {
        await connectDB()
        const models = await initModels();
        await models.sequelize.sync({ alter: false, force: false });
        console.log("✅ Database synced");
        EmailService.transporter.verify()
            .then(() => console.log("✅ SMTP Connected"))
            .catch(err => console.error("❌ SMTP Error:", err));

        app.listen(PORT, () => {
            console.log(`🚀 Server running on port ${PORT}`);
        });
    } catch (error) {
        console.error("❌ Server failed to start:", error);
        process.exit(1);
    }
};

startServer();