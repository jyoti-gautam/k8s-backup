# 📚 Auth API Documentation

**Base URL:** `http://localhost:5000/api/v1/auth`

---

## Role System Overview

This API uses a **slug-based role system** backed by the `roles` table (FK via `roleId`). Legacy enum strings are gone.

### System Roles (scope: `system`)

| Slug             | Description                                                     |
| ---------------- | --------------------------------------------------------------- |
| `system-admin`   | Full system-wide access. Can assign/update/remove system roles. |
| `system-manager` | Manages system-wide configurations and operations.              |
| `system-support` | Handles system-level support and troubleshooting.               |

### Organization Roles (scope: `organization`)

| Slug           | Description                                      |
| -------------- | ------------------------------------------------ |
| `owner`        | Organization owner with full control.            |
| `admin`        | Org administrator managing members and settings. |
| `reseller`     | Reseller managing multiple customers.            |
| `customer`     | Default role for self-registered users.          |
| `project-user` | Standard org member assigned to projects.        |

### JWT Payload Structure

```json
{
  "userId": 1,
  "uuid": "550e8400-...",
  "email": "user@example.com",
  "organizations": [{ "organizationId": 1, "roleId": 4, "roleSlug": "owner" }],
  "systemRoleId": 1,
  "systemRoleSlug": "system-admin"
}
```

> `systemRoleId` / `systemRoleSlug` are only present if the user has a system role.

---

## 🔓 Public Routes

### 1. Register User

**POST** `/register`

Registers a new user and auto-assigns the `customer` org role (looked up by slug → roleId).

**Request Body:**

```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "Password123!",
  "phone": "+1234567890",
  "timezone": "UTC",
  "locale": "en",
  "organizationId": 1
}
```

**Response `201`:**

```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "userId": 1,
    "uuid": "550e8400-e29b-41d4-a716-446655440000",
    "email": "john@example.com",
    "name": "John Doe",
    "message": "Registration successful. Please check your email to verify your account."
  }
}
```

---

### 2. Login

**POST** `/login`

**Request Body:**

```json
{
  "email": "john@example.com",
  "password": "Password123!",
  "deviceName": "Chrome on Windows",
  "twoFactorToken": "123456"
}
```

**Response `200` — Success:**

```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": 1,
      "uuid": "550e8400-e29b-41d4-a716-446655440000",
      "name": "John Doe",
      "email": "john@example.com",
      "status": "active",
      "has2FA": false,
      "systemRole": null,
      "organizations": [
        { "organizationId": 1, "roleId": 5, "roleSlug": "customer" }
      ]
    },
    "tokens": {
      "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "refreshToken": "a1b2c3d4e5f6...",
      "expiresIn": "24h"
    }
  }
}
```

**Response `200` — System Admin Login** (includes `systemRole`):

```json
{
  "data": {
    "user": {
      "systemRole": { "roleId": 1, "roleSlug": "system-admin" },
      "organizations": []
    }
  }
}
```

**Response `200` — 2FA Required:**

```json
{
  "data": {
    "requires2FA": true,
    "method": "totp",
    "message": "Enter your authenticator app code",
    "tempToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

### 3. Refresh Token

**POST** `/refresh-token`

```json
{ "refreshToken": "a1b2c3d4e5f6..." }
```

**Response `200`:**

```json
{
  "data": { "accessToken": "eyJ...", "expiresIn": "24h" }
}
```

---

### 4. Verify Email

**POST** `/verify-email/:token`

---

### 5. Resend Verification Email

**POST** `/email/resend-verification`

```json
{ "email": "john@example.com" }
```

---

### 6. Forgot Password

**POST** `/password/forgot`

```json
{ "email": "john@example.com" }
```

---

### 7. Reset Password

**POST** `/password/reset/:token`

```json
{
  "password": "NewPassword123!",
  "confirmPassword": "NewPassword123!"
}
```

---

## 🔒 Protected Routes

**All protected routes require:**

```
Authorization: Bearer <accessToken>
```

---

### 8. Logout

**POST** `/logout`

Revokes the current session AND clears `accessToken`, `refreshTokenHash`, `refreshTokenExpiresAt` from the `users` table.

---

### 9. Get Profile

**GET** `/profile`

**Response `200`:**

```json
{
  "data": {
    "uuid": "550e8400-...",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "avatarUrl": null,
    "timezone": "UTC",
    "locale": "en",
    "status": "active",
    "emailVerified": true,
    "phoneVerified": false,
    "has2FA": false,
    "organizations": [
      { "organizationId": 1, "roleId": 5, "roleSlug": "customer" }
    ],
    "createdAt": "2024-01-01T00:00:00.000Z"
  }
}
```

---

### 10. Update Profile

**PATCH** `/profile`

```json
{
  "name": "John Updated",
  "phone": "+9876543210",
  "timezone": "America/New_York",
  "locale": "en-US"
}
```

---

### 11. Change Password

**POST** `/password/change`

```json
{
  "currentPassword": "Password123!",
  "newPassword": "NewPassword123!"
}
```

---

## 📱 Session Management

### 12. List Sessions

**GET** `/sessions`

**Response `200`:**

```json
{
  "data": [
    {
      "id": 1,
      "deviceName": "Chrome on Windows",
      "ipAddress": "192.168.1.1",
      "lastActivityAt": "2024-01-15T10:30:00.000Z",
      "createdAt": "2024-01-15T08:00:00.000Z"
    }
  ]
}
```

---

### 13. Revoke Session

**DELETE** `/sessions/:sessionId`

---

### 14. Revoke All Sessions

**DELETE** `/sessions/all`

Revokes all sessions except the current one.

---

## 🔐 Two-Factor Authentication

### 15. Setup 2FA

**POST** `/2fa/setup`

```json
{ "method": "totp" }
```

Methods: `totp` | `email` | `sms`

**Response `200` — TOTP:**

```json
{
  "data": {
    "method": "totp",
    "secret": "JBSWY3DPEHPK3PXP",
    "qrCode": "data:image/png;base64,iVBORw0KGgo...",
    "message": "Scan the QR code and verify to enable TOTP 2FA"
  }
}
```

---

### 16. Enable 2FA

**POST** `/2fa/enable`

```json
{ "token": "123456" }
```

**Response `200`:**

```json
{
  "data": {
    "message": "TOTP 2FA enabled successfully",
    "backupCodes": ["ABCD-1234-EFGH-5678", "..."]
  }
}
```

---

### 17. Disable 2FA

**POST** `/2fa/disable`

```json
{ "password": "Password123!" }
```

---

### 18. Verify 2FA Token

**POST** `/2fa/verify`

```json
{ "token": "123456" }
```

---

### 19. Regenerate Backup Codes

**POST** `/2fa/backup-codes/regenerate`

```json
{ "password": "Password123!" }
```

---

## 👥 Organization Admin Routes

**Required:** `roleSlug` of `owner`, `admin`, or `reseller` in the JWT `organizations[]` for the relevant org.

---

### 20. Create User (by Org Admin)

**POST** `/admin/create-user`

> ⚠️ Field changed: `organizationRole` → **`organizationRoleSlug`**

```json
{
  "name": "New Customer",
  "email": "newcustomer@example.com",
  "password": "Password123!",
  "phone": "+1234567890",
  "timezone": "UTC",
  "locale": "en",
  "organizationId": 1,
  "organizationRoleSlug": "customer"
}
```

**Allowed `organizationRoleSlug` values:** `owner` | `admin` | `customer` | `reseller` | `project-user`

**Response `201`:**

```json
{
  "data": {
    "userId": 5,
    "uuid": "660e8400-...",
    "email": "newcustomer@example.com",
    "name": "New Customer",
    "organizationRoleSlug": "customer"
  }
}
```

---

### 21. Update User Status

**PATCH** `/admin/users/:userId/status`

**Required:** `owner` or `admin` roleSlug.

```json
{ "status": "blocked" }
```

Status values: `active` | `blocked` | `deleted` | `pending_verification`

---

### 22. Unlock User Account

**PATCH** `/admin/users/:userId/unlock`

**Required:** `owner` or `admin` roleSlug.

---

## 🔧 System Admin Routes

**Required:** `systemRoleSlug` in JWT (set at login for system-level users).

---

### 23. Assign System Role

**POST** `/system-users/assign`

**Required:** `systemRoleSlug: system-admin`

> ⚠️ Field changed: `systemRole` → **`systemRoleSlug`**

```json
{
  "userId": 10,
  "systemRoleSlug": "system-manager"
}
```

**Allowed `systemRoleSlug` values:** `system-admin` | `system-manager` | `system-support`

**Response `201`:**

```json
{
  "data": {
    "id": 1,
    "userId": 10,
    "userName": "John Doe",
    "userEmail": "john@example.com",
    "systemRoleSlug": "system-manager",
    "roleId": 2,
    "status": "active",
    "assignedAt": "2024-01-15T10:00:00.000Z"
  }
}
```

---

### 24. Update System Role

**PATCH** `/system-users/:userId`

**Required:** `systemRoleSlug: system-admin`

> ⚠️ Field changed: `systemRole` → **`systemRoleSlug`**

```json
{
  "systemRoleSlug": "system-support",
  "status": "active"
}
```

**Response `200`:**

```json
{
  "data": {
    "id": 1,
    "userId": 10,
    "roleId": 3,
    "status": "active"
  }
}
```

---

### 25. Remove System Role

**DELETE** `/system-users/:userId`

**Required:** `systemRoleSlug: system-admin`

Soft-deletes by setting `status: removed`, `removedAt`, `removedBy`.

---

### 26. List System Users

**GET** `/system-users`

**Required:** Any system role (`system-admin`, `system-manager`, `system-support`)

**Query Parameters:**

| Param      | Values                                                 | Description                             |
| ---------- | ------------------------------------------------------ | --------------------------------------- |
| `roleSlug` | `system-admin` \| `system-manager` \| `system-support` | Filter by role slug                     |
| `status`   | `active` \| `removed`                                  | Filter by status (defaults to `active`) |

**Example:** `GET /system-users?roleSlug=system-admin&status=active`

> ⚠️ Query param changed: `systemRole` → **`roleSlug`**

**Response `200`:**

```json
{
  "data": [
    {
      "id": 1,
      "userId": 1,
      "userName": "System Administrator 1",
      "userEmail": "systemadmin1@aigreentick.com",
      "userStatus": "active",
      "roleId": 1,
      "roleSlug": "system-admin",
      "roleName": "System Admin",
      "status": "active",
      "assignedAt": "2024-01-01T00:00:00.000Z",
      "lastLoginAt": "2024-01-15T09:30:00.000Z"
    }
  ]
}
```

---

## ⚠️ Breaking Changes from Previous Version

| Area                          | Old                    | New                                                                                   |
| ----------------------------- | ---------------------- | ------------------------------------------------------------------------------------- |
| Create user body field        | `organizationRole`     | `organizationRoleSlug`                                                                |
| Assign system role body field | `systemRole`           | `systemRoleSlug`                                                                      |
| Update system role body field | `systemRole`           | `systemRoleSlug`                                                                      |
| List system users query param | `systemRole`           | `roleSlug`                                                                            |
| JWT `organizations[].role`    | `"customer"` (string)  | `{ roleId: 5, roleSlug: "customer" }`                                                 |
| JWT system role field         | `systemRole: "admin"`  | `systemRoleId: 1, systemRoleSlug: "system-admin"`                                     |
| Profile/login response        | `org.role: "customer"` | `org.roleId: 5, org.roleSlug: "customer"`                                             |
| System user list response     | `systemRole: "admin"`  | `roleId: 1, roleSlug: "system-admin", roleName: "System Admin"`                       |
| Token persistence             | Nowhere                | `accessToken` + `refreshTokenHash` saved in `users` table on login; cleared on logout |
