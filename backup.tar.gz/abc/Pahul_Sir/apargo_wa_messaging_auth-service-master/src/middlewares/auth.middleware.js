import jwt from "jsonwebtoken";
import ApiResponse from "../utils/ApiResponse.js";

export const authenticate = (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return ApiResponse.unauthorized(res, "Access token required");
        }

        const token = authHeader.split(" ")[1];

        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Attach user info to request
        req.user = {
            userId: decoded.userId,
            role: decoded.role
        };

        next();
    } catch (error) {
        if (error.name === "TokenExpiredError") {
            return ApiResponse.unauthorized(res, "Token expired");
        }

        return ApiResponse.unauthorized(res, "Invalid token");
    }
};

export const authorize = (roles = [], checkSystemRole = false) => {
    return async (req, res, next) => {
        try {
            if (!req.user) {
                return ApiResponse.unauthorized(res, 'Authentication required');
            }

            let hasPermission = false;

            if (checkSystemRole) {
                if (req.user.systemRole && roles.includes(req.user.systemRole)) {
                    hasPermission = true;
                }
            } else {
                if (req.user.organizationRole && roles.includes(req.user.organizationRole)) {
                    hasPermission = true;
                }
            }

            if (!hasPermission) {
                return ApiResponse.forbidden(res, 'Insufficient permissions');
            }

            next();
        } catch (error) {
            next(error);
        }
    };
};