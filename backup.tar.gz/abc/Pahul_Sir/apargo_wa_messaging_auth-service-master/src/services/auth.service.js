import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { Op } from 'sequelize';
import { v4 as uuidv4 } from 'uuid';
import { getModels } from '../models/index.js';
import EmailService from '../utils/EmailService.js';
import OtpService from '../utils/OtpService.js';
import TwoFactorAuth from '../utils/TwoFactorAuth.js';

class AuthService {

    // =========================
    // HELPER: Look up Role by slug + scope
    // =========================
    async _getRoleId(slug, scope) {
        const { Role } = getModels();
        const role = await Role.findOne({
            where: { slug, scope, organizationId: null, projectId: null }
        });
        if (!role) throw new Error(`Role not found: slug="${slug}" scope="${scope}"`);
        return role.id;
    }

    // =========================
    // REGISTER
    // =========================
    async register(userData) {
        const { User, OrganizationUser } = getModels();
        const { name, email, password, phone, timezone = 'UTC', locale = 'en', organizationId } = userData;

        if (!organizationId) throw new Error('organizationId is required');

        const normalizedEmail = email.toLowerCase().trim();
        const normalizedPhone = phone ? phone.trim() : null;

        const existingEmail = await User.findOne({ where: { email: normalizedEmail } });
        if (existingEmail) throw new Error('User with this email already exists');

        if (normalizedPhone) {
            const existingPhone = await User.findOne({ where: { phone: normalizedPhone } });
            if (existingPhone) throw new Error('User with this phone number already exists');
        }

        const passwordHash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 10);
        const verificationToken = crypto.randomBytes(32).toString('hex');
        const verificationTokenHash = crypto.createHash('sha256').update(verificationToken).digest('hex');
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24);

        const user = await User.create({
            uuid: uuidv4(),
            name,
            email: normalizedEmail,
            passwordHash,
            phone: normalizedPhone,
            timezone,
            locale,
            status: 'pending_verification',
            emailVerificationTokenHash: verificationTokenHash,
            emailVerificationExpiresAt: expiresAt
        });

        // Default role for self-registration = 'customer' (organization scope)
        const customerRoleId = await this._getRoleId('customer', 'organization');
        await OrganizationUser.create({
            userId: user.id,
            organizationId,
            roleId: customerRoleId,
            joinedAt: new Date()
        });

        await EmailService.sendEmailVerification(
            user.email,
            verificationToken,
            `${process.env.FRONTEND_URL}/verify-email/${verificationToken}`
        );

        return {
            userId: user.id,
            uuid: user.uuid,
            email: user.email,
            name: user.name,
            message: 'Registration successful. Please check your email to verify your account.'
        };
    }

    // =========================
    // LOGIN
    // =========================
    async login(loginData) {
        const { User, UserSession, User2FA, OrganizationUser, SystemUser, Role } = getModels();
        const { email, password, deviceName, ipAddress, userAgent, twoFactorToken } = loginData;

        const user = await User.findOne({
            where: { email },
            include: [
                { model: User2FA, as: 'twoFactor' },
                {
                    model: OrganizationUser,
                    as: 'organizationMemberships',
                    include: [{ model: Role, as: 'role' }]
                },
                {
                    model: SystemUser,
                    as: 'systemUser',
                    where: { status: 'active' },
                    required: false,
                    include: [{ model: Role, as: 'role' }]
                }
            ]
        });

        if (!user) throw new Error('Invalid credentials');

        if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
            const minutes = Math.ceil((new Date(user.lockedUntil) - new Date()) / 60000);
            throw new Error(`Account is locked. Please try again in ${minutes} minutes.`);
        }

        if (user.status === 'blocked') throw new Error('Account is blocked. Please contact support.');

        const isPasswordValid = await bcrypt.compare(password, user.passwordHash);

        if (!isPasswordValid) {
            const newAttempts = user.failedLoginAttempts + 1;
            const maxAttempts = parseInt(process.env.MAX_LOGIN_ATTEMPTS) || 5;

            if (newAttempts >= maxAttempts) {
                const lockMinutes = parseInt(process.env.LOCK_TIME_MINUTES) || 30;
                const lockedUntil = new Date();
                lockedUntil.setMinutes(lockedUntil.getMinutes() + lockMinutes);
                await user.update({ failedLoginAttempts: newAttempts, lockedUntil });
                throw new Error(`Account locked due to too many failed attempts. Try again in ${lockMinutes} minutes.`);
            }

            await user.update({ failedLoginAttempts: newAttempts });
            throw new Error('Invalid credentials');
        }

        if (user.twoFactor && user.twoFactor.enabledAt) {
            const method = user.twoFactor.method;
            if (!twoFactorToken) {
                if (method === 'totp') {
                    return {
                        requires2FA: true,
                        method: 'totp',
                        message: 'Enter your authenticator app code',
                        tempToken: this.generateTempToken(user.id)
                    };
                }
                if (method === 'email' || method === 'sms') {
                    await this.sendOtpForMethod(user, method);
                    return {
                        requires2FA: true,
                        method,
                        message: `OTP sent via ${method}`,
                        tempToken: this.generateTempToken(user.id)
                    };
                }
            }
            const isValid = await this.verify2FAToken(user.id, twoFactorToken, ipAddress);
            if (!isValid) throw new Error('Invalid 2FA token');
        }

        await user.update({
            failedLoginAttempts: 0,
            lockedUntil: null,
            lastLoginAt: new Date(),
            lastLoginIp: ipAddress
        });

        const accessToken = this.generateAccessToken(user);
        const refreshToken = this.generateRefreshToken();

        const sessionTokenHash = crypto.createHash('sha256').update(accessToken).digest('hex');
        const refreshTokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');

        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + (parseInt(process.env.SESSION_EXPIRES_HOURS) || 24));

        await UserSession.create({
            userId: user.id,
            sessionTokenHash,
            refreshTokenHash,
            deviceName,
            ipAddress,
            userAgent,
            expiresAt
        });

        // Save tokens to User table
        await user.update({
            accessToken,
            refreshTokenHash,
            refreshTokenExpiresAt: expiresAt
        });

        const organizationMemberships = user.organizationMemberships.map(org => ({
            organizationId: org.organizationId,
            roleId: org.roleId,
            roleSlug: org.role?.slug ?? null
        }));

        return {
            user: {
                id: user.id,
                uuid: user.uuid,
                name: user.name,
                email: user.email,
                status: user.status,
                has2FA: !!(user.twoFactor && user.twoFactor.enabledAt),
                systemRole: user.systemUser ? {
                    roleId: user.systemUser.roleId,
                    roleSlug: user.systemUser.role?.slug ?? null
                } : null,
                organizations: organizationMemberships
            },
            tokens: {
                accessToken,
                refreshToken,
                expiresIn: process.env.JWT_EXPIRES_IN
            }
        };
    }

    // =========================
    // REFRESH TOKEN
    // =========================
    async refreshToken(refreshToken) {
        const { UserSession, User, OrganizationUser, Role } = getModels();
        const refreshTokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');

        const session = await UserSession.findOne({
            where: { refreshTokenHash, revokedAt: null },
            include: [{
                model: User,
                as: 'user',
                include: [{
                    model: OrganizationUser,
                    as: 'organizationMemberships',
                    include: [{ model: Role, as: 'role' }]
                }]
            }]
        });

        if (!session || new Date(session.expiresAt) < new Date()) {
            throw new Error('Invalid or expired refresh token');
        }

        const newAccessToken = this.generateAccessToken(session.user);
        const sessionTokenHash = crypto.createHash('sha256').update(newAccessToken).digest('hex');

        await session.update({ sessionTokenHash, lastActivityAt: new Date() });

        // Update access token in User table
        await session.user.update({ accessToken: newAccessToken });

        return { accessToken: newAccessToken, expiresIn: process.env.JWT_EXPIRES_IN };
    }

    // =========================
    // LOGOUT
    // =========================
    async logout(token, userId) {
        const { UserSession, User } = getModels();
        const sessionTokenHash = crypto.createHash('sha256').update(token).digest('hex');

        await UserSession.update(
            { revokedAt: new Date(), revokedBy: userId, revokeReason: 'user_logout' },
            { where: { sessionTokenHash, userId } }
        );

        // Clear tokens from User table
        await User.update(
            { accessToken: null, refreshTokenHash: null, refreshTokenExpiresAt: null },
            { where: { id: userId } }
        );
    }

    // =========================
    // CREATE USER BY ADMIN
    // =========================
    async createUserByAdmin(userData) {
        const { User, OrganizationUser } = getModels();
        const {
            name, email, password, phone,
            timezone = 'UTC', locale = 'en',
            organizationId, organizationRoleSlug, createdBy
        } = userData;

        const normalizedEmail = email.toLowerCase().trim();
        const normalizedPhone = phone ? phone.trim() : null;

        const existingEmail = await User.findOne({ where: { email: normalizedEmail } });
        if (existingEmail) throw new Error('User with this email already exists');

        if (normalizedPhone) {
            const existingPhone = await User.findOne({ where: { phone: normalizedPhone } });
            if (existingPhone) throw new Error('User with this phone number already exists');
        }

        // Validate + resolve role
        const allowedRoleSlugs = ['owner', 'admin', 'customer', 'reseller', 'project-user'];
        if (!allowedRoleSlugs.includes(organizationRoleSlug)) {
            throw new Error(`Invalid organization role. Allowed: ${allowedRoleSlugs.join(', ')}`);
        }
        const roleId = await this._getRoleId(organizationRoleSlug, 'organization');

        const passwordHash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 10);

        const user = await User.create({
            uuid: uuidv4(),
            name,
            email: normalizedEmail,
            passwordHash,
            phone: normalizedPhone,
            timezone,
            locale,
            status: 'active',
            emailVerifiedAt: new Date()
        });

        if (organizationId) {
            await OrganizationUser.create({
                userId: user.id,
                organizationId,
                roleId,
                joinedAt: new Date()
            });
        }

        return {
            userId: user.id,
            uuid: user.uuid,
            email: user.email,
            name: user.name,
            organizationRoleSlug
        };
    }

    // =========================
    // ASSIGN SYSTEM ROLE
    // =========================
    async assignSystemRole(userData, assignerId) {
        const { User, SystemUser } = getModels();
        const { userId, systemRoleSlug } = userData;

        const user = await User.findByPk(userId);
        if (!user) throw new Error('User not found');

        const existing = await SystemUser.findOne({ where: { userId, status: 'active' } });
        if (existing) throw new Error('User already has a system role assigned');

        const allowedSlugs = ['system-admin', 'system-manager', 'system-support'];
        if (!allowedSlugs.includes(systemRoleSlug)) {
            throw new Error(`Invalid system role. Allowed: ${allowedSlugs.join(', ')}`);
        }

        const roleId = await this._getRoleId(systemRoleSlug, 'system');

        const systemUser = await SystemUser.create({
            userId,
            roleId,
            status: 'active',
            assignedAt: new Date(),
            assignedBy: assignerId
        });

        return {
            id: systemUser.id,
            userId: user.id,
            userName: user.name,
            userEmail: user.email,
            systemRoleSlug,
            roleId,
            status: systemUser.status,
            assignedAt: systemUser.assignedAt
        };
    }

    // =========================
    // UPDATE SYSTEM ROLE
    // =========================
    async updateSystemRole(userId, updates, updaterId) {
        const { SystemUser } = getModels();

        const systemUser = await SystemUser.findOne({ where: { userId, status: 'active' } });
        if (!systemUser) throw new Error('System user role not found');

        const filteredUpdates = {};

        if (updates.systemRoleSlug) {
            const allowedSlugs = ['system-admin', 'system-manager', 'system-support'];
            if (!allowedSlugs.includes(updates.systemRoleSlug)) {
                throw new Error(`Invalid system role. Allowed: ${allowedSlugs.join(', ')}`);
            }
            filteredUpdates.roleId = await this._getRoleId(updates.systemRoleSlug, 'system');
        }

        if (updates.status) {
            filteredUpdates.status = updates.status;
            if (updates.status === 'removed') {
                filteredUpdates.removedAt = new Date();
                filteredUpdates.removedBy = updaterId;
            }
        }

        await systemUser.update(filteredUpdates);

        return {
            id: systemUser.id,
            userId: systemUser.userId,
            roleId: systemUser.roleId,
            status: systemUser.status
        };
    }

    // =========================
    // REMOVE SYSTEM ROLE
    // =========================
    async removeSystemRole(userId, removerId) {
        const { SystemUser } = getModels();

        const systemUser = await SystemUser.findOne({ where: { userId, status: 'active' } });
        if (!systemUser) throw new Error('System user role not found');

        await systemUser.update({
            status: 'removed',
            removedAt: new Date(),
            removedBy: removerId
        });

        return { message: 'System role removed successfully' };
    }

    // =========================
    // LIST SYSTEM USERS
    // =========================
    async listSystemUsers(filters = {}) {
        const { User, SystemUser, Role } = getModels();
        const { roleSlug, status } = filters;

        const where = { status: status || 'active' };

        const systemUsers = await SystemUser.findAll({
            where,
            include: [
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'uuid', 'name', 'email', 'status', 'lastLoginAt']
                },
                {
                    model: Role,
                    as: 'role',
                    attributes: ['id', 'name', 'slug'],
                    ...(roleSlug ? { where: { slug: roleSlug } } : {})
                }
            ],
            order: [['assignedAt', 'DESC']]
        });

        return systemUsers.map(su => ({
            id: su.id,
            userId: su.userId,
            userName: su.user.name,
            userEmail: su.user.email,
            userStatus: su.user.status,
            roleId: su.roleId,
            roleSlug: su.role?.slug ?? null,
            roleName: su.role?.name ?? null,
            status: su.status,
            assignedAt: su.assignedAt,
            lastLoginAt: su.user.lastLoginAt
        }));
    }

    // =========================
    // GENERATE ACCESS TOKEN
    // =========================
    generateAccessToken(user) {
        const organizationMemberships = user.organizationMemberships
            ? user.organizationMemberships.map(org => ({
                organizationId: org.organizationId,
                roleId: org.roleId,
                roleSlug: org.role?.slug ?? null
            }))
            : [];

        const payload = {
            userId: user.id,
            uuid: user.uuid,
            email: user.email,
            organizations: organizationMemberships
        };

        // Attach system role to token if present
        if (user.systemUser && user.systemUser.status === 'active') {
            payload.systemRoleId = user.systemUser.roleId;
            payload.systemRoleSlug = user.systemUser.role?.slug ?? null;
        }

        return jwt.sign(payload, process.env.JWT_SECRET, {
            expiresIn: process.env.JWT_EXPIRES_IN
        });
    }

    // =========================
    // GET PROFILE
    // =========================
    async getProfile(userId) {
        const { User, User2FA, OrganizationUser, Role } = getModels();
        const user = await User.findByPk(userId, {
            include: [
                { model: User2FA, as: 'twoFactor' },
                {
                    model: OrganizationUser,
                    as: 'organizationMemberships',
                    include: [{ model: Role, as: 'role' }]
                }
            ]
        });

        if (!user) throw new Error('User not found');

        return {
            uuid: user.uuid,
            name: user.name,
            email: user.email,
            phone: user.phone,
            avatarUrl: user.avatarUrl,
            timezone: user.timezone,
            locale: user.locale,
            status: user.status,
            emailVerified: !!user.emailVerifiedAt,
            phoneVerified: !!user.phoneVerifiedAt,
            has2FA: !!(user.twoFactor && user.twoFactor.enabledAt),
            organizations: user.organizationMemberships.map(org => ({
                organizationId: org.organizationId,
                roleId: org.roleId,
                roleSlug: org.role?.slug ?? null
            })),
            createdAt: user.createdAt
        };
    }

    // ---- All unchanged methods below (kept as-is) ----

    async verifyEmail(token) {
        const { User } = getModels();
        const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
        const user = await User.findOne({
            where: { emailVerificationTokenHash: tokenHash, emailVerifiedAt: null }
        });
        if (!user) throw new Error('Invalid or expired verification token');
        if (new Date(user.emailVerificationExpiresAt) < new Date()) throw new Error('Verification token has expired');
        await user.update({
            emailVerifiedAt: new Date(),
            status: 'active',
            emailVerificationTokenHash: null,
            emailVerificationExpiresAt: null
        });
        return { message: 'Email verified successfully' };
    }

    async setup2FA(userId, method = 'totp') {
        const { User, User2FA } = getModels();
        const allowedMethods = ['totp', 'email', 'sms'];
        if (!allowedMethods.includes(method)) throw new Error('Invalid 2FA method');
        const user = await User.findByPk(userId);
        if (!user) throw new Error('User not found');
        const existing = await User2FA.findOne({ where: { userId, method } });
        if (existing && existing.enabledAt) throw new Error(`${method.toUpperCase()} 2FA is already enabled`);

        if (method === 'totp') {
            const { secret, otpauthUrl } = TwoFactorAuth.generateSecret(user.email);
            const qrCode = await TwoFactorAuth.generateQRCode(otpauthUrl);
            const encryptedSecret = TwoFactorAuth.encryptSecret(secret);
            await User2FA.upsert({ userId, method: 'totp', secretEnc: encryptedSecret, enabledAt: null });
            return { method: 'totp', secret, qrCode, message: 'Scan the QR code and verify to enable TOTP 2FA' };
        }
        if (method === 'email') {
            await User2FA.upsert({ userId, method: 'email', secretEnc: null, enabledAt: null });
            await this.sendOtpForMethod(user, 'email');
            return { method: 'email', message: 'OTP sent to your email. Verify to enable Email 2FA.' };
        }
        if (method === 'sms') {
            if (!user.phone) throw new Error('Phone number required for SMS 2FA');
            await User2FA.upsert({ userId, method: 'sms', secretEnc: null, enabledAt: null });
            return { method: 'sms', message: 'SMS 2FA ready. OTP will be sent to your phone.' };
        }
    }

    async enable2FA(userId, token) {
        const { User2FA, User2FABackupCode } = getModels();
        const twoFactor = await User2FA.findOne({ where: { userId } });
        if (!twoFactor) throw new Error('2FA setup not initiated');
        if (twoFactor.enabledAt) throw new Error('2FA is already enabled');

        let isValid = false;
        if (twoFactor.method === 'totp') {
            const secret = TwoFactorAuth.decryptSecret(twoFactor.secretEnc);
            isValid = TwoFactorAuth.verifyToken(secret, token);
        }
        if (twoFactor.method === 'email' || twoFactor.method === 'sms') {
            if (!twoFactor.otpCodeHash || new Date(twoFactor.otpExpiresAt) < new Date()) throw new Error('OTP expired');
            isValid = await OtpService.verifyOTP(token, twoFactor.otpCodeHash);
        }
        if (!isValid) throw new Error('Invalid verification token');

        const backupCodes = TwoFactorAuth.generateBackupCodes(parseInt(process.env.BACKUP_CODES_COUNT) || 10);
        await Promise.all(backupCodes.map(async (code) => {
            const codeHash = await TwoFactorAuth.hashBackupCode(code);
            return User2FABackupCode.create({ userId, codeHash });
        }));
        await twoFactor.update({ enabledAt: new Date(), otpCodeHash: null, otpExpiresAt: null, backupCodesGeneratedAt: new Date() });
        return { message: `${twoFactor.method.toUpperCase()} 2FA enabled successfully`, backupCodes };
    }

    async disable2FA(userId, password) {
        const { User, User2FA, User2FABackupCode, UserSession } = getModels();
        const user = await User.findByPk(userId);
        if (!user) throw new Error('User not found');
        const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
        if (!isPasswordValid) throw new Error('Invalid password');
        const twoFactor = await User2FA.findOne({ where: { userId } });
        if (!twoFactor || !twoFactor.enabledAt) throw new Error('2FA is not enabled');
        await User2FABackupCode.destroy({ where: { userId } });
        await twoFactor.destroy();
        await UserSession.update({ revokedAt: new Date(), revokeReason: '2fa_disabled' }, { where: { userId } });
        return { message: '2FA disabled successfully. All sessions have been revoked.' };
    }

    async verify2FAToken(userId, token, ipAddress) {
        const { User2FA, User2FABackupCode } = getModels();
        const twoFactor = await User2FA.findOne({ where: { userId } });
        if (!twoFactor || !twoFactor.enabledAt) throw new Error('2FA is not enabled');

        if (twoFactor.method === 'totp') {
            const secret = TwoFactorAuth.decryptSecret(twoFactor.secretEnc);
            if (TwoFactorAuth.verifyToken(secret, token)) {
                await twoFactor.update({ lastUsedAt: new Date() });
                return true;
            }
        }
        if (twoFactor.method === 'email' || twoFactor.method === 'sms') {
            if (!twoFactor.otpCodeHash || new Date(twoFactor.otpExpiresAt) < new Date()) throw new Error('OTP expired');
            if (await OtpService.verifyOTP(token, twoFactor.otpCodeHash)) {
                await twoFactor.update({ lastUsedAt: new Date(), otpCodeHash: null, otpExpiresAt: null });
                return true;
            }
        }
        const backupCodes = await User2FABackupCode.findAll({ where: { userId, usedAt: null } });
        for (const backupCode of backupCodes) {
            if (await TwoFactorAuth.verifyBackupCode(token, backupCode.codeHash)) {
                await backupCode.update({ usedAt: new Date(), usedIp: ipAddress });
                await twoFactor.update({ lastUsedAt: new Date() });
                return true;
            }
        }
        return false;
    }

    async updateUserStatus(userId, status, adminId) {
        const { User } = getModels();
        const user = await User.findByPk(userId);
        if (!user) throw new Error('User not found');
        await user.update({ status });
        return { message: `User status updated to ${status}` };
    }

    async unlockUserAccount(userId, adminId) {
        const { User } = getModels();
        const user = await User.findByPk(userId);
        if (!user) throw new Error('User not found');
        await user.update({ lockedUntil: null, failedLoginAttempts: 0 });
        return { message: 'User account unlocked' };
    }

    async regenerateBackupCodes(userId, password) {
        const { User, User2FA, User2FABackupCode } = getModels();
        const user = await User.findByPk(userId);
        if (!user) throw new Error('User not found');
        const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
        if (!isPasswordValid) throw new Error('Invalid password');
        const twoFactor = await User2FA.findOne({ where: { userId } });
        if (!twoFactor || !twoFactor.enabledAt) throw new Error('2FA is not enabled');
        await User2FABackupCode.destroy({ where: { userId } });
        const backupCodes = TwoFactorAuth.generateBackupCodes(parseInt(process.env.BACKUP_CODES_COUNT) || 10);
        await Promise.all(backupCodes.map(async (code) => {
            const codeHash = await TwoFactorAuth.hashBackupCode(code);
            return User2FABackupCode.create({ userId, codeHash });
        }));
        await twoFactor.update({ backupCodesGeneratedAt: new Date() });
        return { backupCodes, message: 'Backup codes regenerated successfully' };
    }

    async resendVerificationEmail(email) {
        const { User } = getModels();
        const user = await User.findOne({ where: { email: email.toLowerCase().trim() } });
        if (!user) return { message: 'If email exists, verification link sent' };
        if (user.emailVerifiedAt) throw new Error('Email already verified');
        const verificationToken = crypto.randomBytes(32).toString('hex');
        const verificationTokenHash = crypto.createHash('sha256').update(verificationToken).digest('hex');
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24);
        await user.update({ emailVerificationTokenHash: verificationTokenHash, emailVerificationExpiresAt: expiresAt });
        await EmailService.sendEmailVerification(user.email, verificationToken, `${process.env.FRONTEND_URL}/verify-email/${verificationToken}`);
        return { message: 'Verification email sent' };
    }

    async forgotPassword(email) {
        const { User } = getModels();
        const user = await User.findOne({ where: { email: email.toLowerCase().trim() } });
        if (!user) return { message: 'If email exists, password reset link sent' };
        const resetToken = crypto.randomBytes(32).toString('hex');
        const resetTokenHash = crypto.createHash('sha256').update(resetToken).digest('hex');
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 1);
        await user.update({ passwordResetTokenHash: resetTokenHash, passwordResetExpiresAt: expiresAt, passwordResetUsedAt: null });
        await EmailService.sendPasswordReset(user.email, resetToken, `${process.env.FRONTEND_URL}/reset-password/${resetToken}`);
        return { message: 'Password reset email sent' };
    }

    async resetPassword(token, newPassword) {
        const { User } = getModels();
        const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
        const user = await User.findOne({ where: { passwordResetTokenHash: tokenHash, passwordResetUsedAt: null } });
        if (!user) throw new Error('Invalid or expired reset token');
        if (new Date(user.passwordResetExpiresAt) < new Date()) throw new Error('Reset token has expired');
        const passwordHash = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 10);
        await user.update({ passwordHash, passwordResetTokenHash: null, passwordResetExpiresAt: null, passwordResetUsedAt: new Date() });
        return { message: 'Password reset successfully' };
    }

    async changePassword(userId, currentPassword, newPassword) {
        const { User, UserSession } = getModels();
        const user = await User.findByPk(userId);
        if (!user) throw new Error('User not found');
        const isPasswordValid = await bcrypt.compare(currentPassword, user.passwordHash);
        if (!isPasswordValid) throw new Error('Invalid password');
        const passwordHash = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 10);
        await user.update({ passwordHash });
        await UserSession.update({ revokedAt: new Date(), revokeReason: 'password_changed' }, { where: { userId } });
        return { message: 'Password changed successfully. Please log in again.' };
    }

    async updateProfile(userId, updates) {
        const { User } = getModels();
        const user = await User.findByPk(userId);
        if (!user) throw new Error('User not found');
        const allowedUpdates = ['name', 'phone', 'timezone', 'locale', 'avatarUrl'];
        const filteredUpdates = {};
        for (const key of allowedUpdates) {
            if (updates[key] !== undefined) filteredUpdates[key] = updates[key];
        }
        await user.update(filteredUpdates);
        return this.getProfile(userId);
    }

    async listSessions(userId) {
        const { UserSession } = getModels();
        return UserSession.findAll({
            where: { userId, revokedAt: null, expiresAt: { [Op.gt]: new Date() } },
            order: [['lastActivityAt', 'DESC']],
            attributes: ['id', 'deviceName', 'ipAddress', 'lastActivityAt', 'createdAt']
        });
    }

    async revokeSession(userId, sessionId) {
        const { UserSession } = getModels();
        const session = await UserSession.findOne({ where: { id: sessionId, userId } });
        if (!session) throw new Error('Session not found');
        await session.update({ revokedAt: new Date(), revokedBy: userId, revokeReason: 'user_revoked' });
        return { message: 'Session revoked' };
    }

    async revokeAllSessions(userId, currentToken) {
        const { UserSession } = getModels();
        const currentTokenHash = crypto.createHash('sha256').update(currentToken).digest('hex');
        await UserSession.update(
            { revokedAt: new Date(), revokedBy: userId, revokeReason: 'user_revoked_all' },
            { where: { userId, sessionTokenHash: { [Op.ne]: currentTokenHash }, revokedAt: null } }
        );
        return { message: 'All other sessions revoked' };
    }

    generateRefreshToken() { return crypto.randomBytes(40).toString('hex'); }

    generateTempToken(userId) {
        return jwt.sign({ userId, temp: true }, process.env.JWT_SECRET, { expiresIn: '5m' });
    }

    async sendOtpForMethod(user, method) {
        const { User2FA } = getModels();
        const twoFactor = await User2FA.findOne({ where: { userId: user.id } });
        if (twoFactor.otpLastSentAt && new Date() - new Date(twoFactor.otpLastSentAt) < 60000) {
            throw new Error('OTP already sent. Please wait 60 seconds.');
        }
        const otp = OtpService.generateOTP();
        const otpHash = await OtpService.hashOTP(otp);
        const expiresAt = new Date();
        expiresAt.setMinutes(expiresAt.getMinutes() + 5);
        await User2FA.update(
            { otpCodeHash: otpHash, otpExpiresAt: expiresAt, otpLastSentAt: new Date() },
            { where: { userId: user.id } }
        );
        if (method === 'email') await EmailService.sendOTP(user.email, otp);
        if (method === 'sms') console.log(`Send SMS via provider: ${otp}`);
    }
}

export default new AuthService();