import express from 'express';
import authController from '../controllers/auth.controller.js';
import { authenticate, authorize } from '../middlewares/auth.middleware.js';
import {
    validate2FAToken,
    validateAdminCreateUser,
    validateEmail,
    validateLogin,
    validatePassword,
    validatePasswordChange,
    validatePasswordReset,
    validateProfileUpdate,
    validateRegister,
    validateSystemUserCreate,
    validateSystemUserUpdate,
    validateUserStatus
} from '../validators/auth.validator.js';

const router = express.Router();

// Public routes
router.post('/register', validateRegister, authController.register);
router.post('/login', validateLogin, authController.login);
router.post('/refresh-token', authController.refreshToken);
router.post('/verify-email/:token', authController.verifyEmail);
router.post('/email/resend-verification', validateEmail, authController.resendVerificationEmail);
router.post('/password/forgot', validateEmail, authController.forgotPassword);
router.post('/password/reset/:token', validatePasswordReset, authController.resetPassword);


// Protected routes
router.use(authenticate); // All routes below require authentication

router.post('/logout', authController.logout);
router.get('/profile', authController.getProfile);
router.patch('/profile', validateProfileUpdate, authController.updateProfile);
router.post('/password/change', validatePasswordChange, authController.changePassword);

router.get('/sessions', authController.listSessions);
router.delete('/sessions/:sessionId', authController.revokeSession);
router.delete('/sessions/all', authController.revokeAllSessions);


// 2FA routes
router.post('/2fa/setup', authController.setup2FA);
router.post('/2fa/enable', validate2FAToken, authController.enable2FA);
router.post('/2fa/disable', validatePassword, authController.disable2FA);
router.post('/2fa/verify', validate2FAToken, authController.verify2FA);
router.post('/2fa/backup-codes/regenerate', validatePassword, authController.regenerateBackupCodes);

// Admin org routes — check org role slugs
router.post('/admin/create-user',
    authorize(['owner', 'admin', 'reseller']),  // org role slugs
    validateAdminCreateUser,
    authController.createUserByAdmin
);

router.patch('/admin/users/:userId/status',
    authorize(['owner', 'admin']),
    validateUserStatus,
    authController.updateUserStatus
);

router.patch('/admin/users/:userId/unlock',
    authorize(['owner', 'admin']),
    authController.unlockUserAccount
);

// System routes — check systemRoleSlug
router.post('/system-users/assign',
    authorize(['system-admin'], true),
    validateSystemUserCreate,
    authController.assignSystemRole
);

router.patch('/system-users/:userId',
    authorize(['system-admin'], true),
    validateSystemUserUpdate,
    authController.updateSystemRole
);

router.delete('/system-users/:userId',
    authorize(['system-admin'], true),
    authController.removeSystemRole
);

router.get('/system-users',
    authorize(['system-admin'], true),
    authController.listSystemUsers
);

export default router;