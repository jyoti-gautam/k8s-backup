import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const Organization = sequelize.define('Organization', {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true
        },
        parentOrganizationId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: true,
            field: 'parent_organization_id'
        },
        uuid: {
            type: DataTypes.CHAR(36),
            allowNull: false,
            unique: true,
            defaultValue: DataTypes.UUIDV4
        },
        slug: {
            type: DataTypes.STRING(100),
            allowNull: false,
            unique: true
        },
        name: {
            type: DataTypes.STRING(200),
            allowNull: false
        },
        displayName: {
            type: DataTypes.STRING(200),
            allowNull: true,
            field: 'display_name'
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        logoUrl: {
            type: DataTypes.STRING(500),
            allowNull: true,
            field: 'logo_url'
        },
        website: {
            type: DataTypes.STRING(500),
            allowNull: true
        },
        organizationType: {
            type: DataTypes.ENUM('organization', 'reseller'),
            allowNull: false,
            field: 'organization_type'
        },
        resellerLevel: {
            type: DataTypes.INTEGER.UNSIGNED,
            defaultValue: 0,
            field: 'reseller_level'
        },
        pricingStrategy: {
            type: DataTypes.ENUM('inherit', 'override'),
            defaultValue: 'inherit',
            field: 'pricing_strategy'
        },
        maxChildResellers: {
            type: DataTypes.INTEGER.UNSIGNED,
            allowNull: true,
            field: 'max_child_resellers'
        },
        ownerUserId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
            field: 'owner_user_id'
        },
        status: {
            type: DataTypes.ENUM('active', 'suspended', 'trial', 'cancelled'),
            defaultValue: 'active'
        },
        trialEndsAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'trial_ends_at'
        },
        metadata: {
            type: DataTypes.JSON,
            defaultValue: {}
        },
        deletedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'deleted_at'
        }
    }, {
        tableName: 'organizations',
        timestamps: true,
        underscored: true,
        paranoid: true,
        indexes: [
            { fields: ['parent_organization_id'] },
            { fields: ['organization_type'] },
            { fields: ['slug'], unique: true },
            { fields: ['uuid'], unique: true },
            { fields: ['owner_user_id'] },
            { fields: ['status'] }
        ]
    });

    Organization.associate = (models) => {
        // Self-referential association for parent organization
        Organization.belongsTo(models.Organization, {
            foreignKey: 'parentOrganizationId',
            as: 'parentOrganization'
        });

        Organization.hasMany(models.Organization, {
            foreignKey: 'parentOrganizationId',
            as: 'childOrganizations'
        });

        // Owner relationship
        Organization.belongsTo(models.User, {
            foreignKey: 'ownerUserId',
            as: 'owner'
        });

        // Organization users
        Organization.hasMany(models.OrganizationUser, {
            foreignKey: 'organizationId',
            as: 'organizationUsers'
        });

        // Projects
        Organization.hasMany(models.Project, {
            foreignKey: 'organizationId',
            as: 'projects'
        });
    };

    return Organization;
};