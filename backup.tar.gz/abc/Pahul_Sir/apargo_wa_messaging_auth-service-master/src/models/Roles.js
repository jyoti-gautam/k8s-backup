import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const Role = sequelize.define('Role', {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true
        },
        uuid: {
            type: DataTypes.CHAR(36),
            allowNull: false,
            unique: true,
            defaultValue: DataTypes.UUIDV4
        },
        name: {
            type: DataTypes.STRING(100),
            allowNull: false
        },
        slug: {
            type: DataTypes.STRING(100),
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        scope: {
            type: DataTypes.ENUM('system', 'organization', 'project'),
            allowNull: false
        },
        // null = system-level role (seeded, belongs to no org)
        organizationId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: true,
            field: 'organization_id'
        },
        // null unless scope = 'project'
        projectId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: true,
            field: 'project_id'
        },
        // null = seeded/default role, set = user-created custom role
        createdBy: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: true,
            field: 'created_by'
        },
        isDefault: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_default',
            comment: 'true = seeded default role that orgs/projects get out of the box'
        },
        isSystem: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_system',
            comment: 'true = locked, cannot be edited or deleted by anyone'
        },
        status: {
            type: DataTypes.ENUM('active', 'inactive'),
            defaultValue: 'active'
        },
        deletedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'deleted_at'
        }
    }, {
        tableName: 'roles',
        timestamps: true,
        underscored: true,
        paranoid: true,
        indexes: [
            { fields: ['uuid'], unique: true },
            { fields: ['scope'] },
            { fields: ['organization_id'] },
            { fields: ['project_id'] },
            { fields: ['created_by'] },
            { fields: ['is_default'] },
            { fields: ['is_system'] },
            { fields: ['status'] },
            // slug unique per scope + org + project combo
            {
                fields: ['slug', 'scope', 'organization_id', 'project_id'],
                unique: true,
                name: 'roles_slug_scope_org_project_unique'
            }
        ]
    });

    return Role;
};