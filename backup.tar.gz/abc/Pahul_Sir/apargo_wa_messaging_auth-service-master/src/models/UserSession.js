import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const UserSession = sequelize.define('UserSession', {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true
        },
        userId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
            field: 'user_id'
        },
        sessionTokenHash: {
            type: DataTypes.STRING(255),
            allowNull: false,
            unique: true,
            field: 'session_token_hash'
        },
        refreshTokenHash: {
            type: DataTypes.STRING(255),
            allowNull: false,
            unique: true,
            field: 'refresh_token_hash'
        },
        deviceName: {
            type: DataTypes.STRING(255),
            allowNull: true,
            field: 'device_name'
        },
        ipAddress: {
            type: DataTypes.STRING(45),
            allowNull: true,
            field: 'ip_address'
        },
        userAgent: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'user_agent'
        },
        lastActivityAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW,
            field: 'last_activity_at'
        },
        expiresAt: {
            type: DataTypes.DATE,
            allowNull: false,
            field: 'expires_at'
        },
        revokedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'revoked_at'
        },
        revokedBy: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: true,
            field: 'revoked_by'
        },
        revokeReason: {
            type: DataTypes.STRING(255),
            allowNull: true,
            field: 'revoke_reason'
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW,
            field: 'created_at'
        }
    }, {
        tableName: 'user_sessions',
        timestamps: false,
        indexes: [
            { fields: ['user_id'] },
            { fields: ['expires_at'] },
            { fields: ['session_token_hash'] },
            { fields: ['last_activity_at'] }
        ]
    });

    return UserSession;
};