import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const User2FA = sequelize.define('User2FA', {
        userId: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            field: 'user_id'
        },
        method: {
            type: DataTypes.ENUM('totp', 'sms', 'email'),
            allowNull: false,
            defaultValue: 'totp'
        },
        secretEnc: {
            type: DataTypes.TEXT,
            allowNull: false,
            field: 'secret_enc',
            comment: 'Encrypted TOTP secret'
        },
        backupCodesGeneratedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'backup_codes_generated_at'
        },
        otpCodeHash: {
            type: DataTypes.STRING(255),
            allowNull: true,
            field: 'otp_code_hash'
        },
        otpExpiresAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'otp_expires_at'
        },
        enabledAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'enabled_at'
        },
        lastUsedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'last_used_at'
        },
        recoveryEmail: {
            type: DataTypes.STRING(190),
            allowNull: true,
            field: 'recovery_email'
        }
    }, {
        tableName: 'user_2fa',
        timestamps: false
    });

    return User2FA;
};