import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const OrganizationUser = sequelize.define('OrganizationUser', {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true
        },
        organizationId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
            field: 'organization_id'
        },
        userId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
            field: 'user_id'
        },
        // FK to roles table (scope = 'organization')
        roleId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
            field: 'role_id'
        },
        status: {
            type: DataTypes.ENUM('active', 'removed'),
            defaultValue: 'active'
        },
        joinedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'joined_at'
        },
        removedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'removed_at'
        },
        removedBy: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: true,
            field: 'removed_by'
        }
    }, {
        tableName: 'organization_users',
        timestamps: true,
        underscored: true,
        indexes: [
            { fields: ['organization_id'] },
            { fields: ['user_id'] },
            { fields: ['role_id'] },
            { fields: ['status'] },
            { fields: ['organization_id', 'user_id'], unique: true }
        ]
    });

    return OrganizationUser;
};