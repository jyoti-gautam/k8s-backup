import sequelize from "../config/db.js";
import defineOrganizationModel from "./Organization.js";
import defineOrganizationUserModel from "./OrganizationUsers.js";
import defineRole from "./Roles.js";
import defineSystemUser from "./SystemUser.js";
import defineUser from "./User.js";
import defineUser2FA from "./User2FA.js";
import defineUser2FABackupCode from "./User2FABackupCode.js";
import defineUserSession from "./UserSession.js";

let models;

export const initModels = async () => {
    const User = defineUser(sequelize);
    const UserSession = defineUserSession(sequelize);
    const User2FA = defineUser2FA(sequelize);
    const User2FABackupCode = defineUser2FABackupCode(sequelize);
    const Organization = defineOrganizationModel(sequelize);
    const OrganizationUser = defineOrganizationUserModel(sequelize);
    const SystemUser = defineSystemUser(sequelize);
    const Role = defineRole(sequelize);

    // =========================
    // User ↔ Session
    // =========================
    User.hasMany(UserSession, { foreignKey: 'userId', as: 'sessions' });
    UserSession.belongsTo(User, { foreignKey: 'userId', as: 'user' });

    // =========================
    // User ↔ 2FA
    // =========================
    User.hasOne(User2FA, { foreignKey: 'userId', as: 'twoFactor' });
    User2FA.belongsTo(User, { foreignKey: 'userId', as: 'user' });

    // =========================
    // User ↔ 2FA Backup Codes
    // =========================
    User.hasMany(User2FABackupCode, { foreignKey: 'userId', as: 'backupCodes' });
    User2FABackupCode.belongsTo(User, { foreignKey: 'userId', as: 'user' });

    // =========================
    // Role (self-contained, no parent)
    // =========================

    // Role → Organization (which org this custom role belongs to, null = system seeded)
    Role.belongsTo(Organization, { foreignKey: 'organizationId', as: 'organization' });
    Organization.hasMany(Role, { foreignKey: 'organizationId', as: 'roles' });

    // Role → User (who created this custom role)
    Role.belongsTo(User, { foreignKey: 'createdBy', as: 'creator' });

    // =========================
    // SystemUser ↔ User
    // =========================
    User.hasOne(SystemUser, { foreignKey: 'userId', as: 'systemUser' });
    SystemUser.belongsTo(User, { foreignKey: 'userId', as: 'user' });

    // SystemUser ↔ Role (scope = 'system')
    SystemUser.belongsTo(Role, { foreignKey: 'roleId', as: 'role' });
    Role.hasMany(SystemUser, { foreignKey: 'roleId', as: 'systemUsers' });

    // SystemUser → User (who assigned)
    SystemUser.belongsTo(User, { foreignKey: 'assignedBy', as: 'assigner' });

    // SystemUser → User (who removed)
    SystemUser.belongsTo(User, { foreignKey: 'removedBy', as: 'remover' });

    // =========================
    // Organization
    // =========================

    // Organization → User (owner)
    Organization.belongsTo(User, { foreignKey: 'ownerUserId', as: 'owner' });

    // Organization self-referential (parent/child)
    Organization.belongsTo(Organization, { foreignKey: 'parentOrganizationId', as: 'parentOrganization' });
    Organization.hasMany(Organization, { foreignKey: 'parentOrganizationId', as: 'childOrganizations' });

    // =========================
    // OrganizationUser
    // =========================

    // OrganizationUser ↔ User
    User.hasMany(OrganizationUser, { foreignKey: 'userId', as: 'organizationMemberships' });
    OrganizationUser.belongsTo(User, { foreignKey: 'userId', as: 'user' });

    // OrganizationUser ↔ Organization
    Organization.hasMany(OrganizationUser, { foreignKey: 'organizationId', as: 'members' });
    OrganizationUser.belongsTo(Organization, { foreignKey: 'organizationId', as: 'organization' });

    // OrganizationUser ↔ Role (scope = 'organization')
    OrganizationUser.belongsTo(Role, { foreignKey: 'roleId', as: 'role' });
    Role.hasMany(OrganizationUser, { foreignKey: 'roleId', as: 'organizationUsers' });

    // OrganizationUser → User (who removed)
    OrganizationUser.belongsTo(User, { foreignKey: 'removedBy', as: 'remover' });

    // =========================
    // Compile models
    // =========================
    models = {
        sequelize,
        User,
        UserSession,
        User2FA,
        User2FABackupCode,
        Role,
        Organization,
        OrganizationUser,
        SystemUser
    };

    return models;
};

export const getModels = () => {
    if (!models) {
        throw new Error('Models not initialized. Call initModels() first.');
    }
    return models;
};