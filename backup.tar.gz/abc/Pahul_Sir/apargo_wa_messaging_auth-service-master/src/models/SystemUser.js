import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const SystemUser = sequelize.define('SystemUser', {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true
        },
        userId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
            field: 'user_id',
            references: {
                model: 'users',
                key: 'id'
            },
            onDelete: 'CASCADE'
        },
        // FK → roles table (scope = 'system')
        roleId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
            field: 'role_id',
            references: {
                model: 'roles',
                key: 'id'
            },
            onDelete: 'RESTRICT'
        },
        status: {
            type: DataTypes.ENUM('active', 'removed'),
            defaultValue: 'active'
        },
        assignedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'assigned_at'
        },
        assignedBy: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: true,
            field: 'assigned_by',
            references: {
                model: 'users',
                key: 'id'
            },
            onDelete: 'SET NULL'
        },
        removedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'removed_at'
        },
        removedBy: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: true,
            field: 'removed_by',
            references: {
                model: 'users',
                key: 'id'
            },
            onDelete: 'SET NULL'
        }
    }, {
        tableName: 'system_users',
        timestamps: true,
        underscored: true,
        indexes: [
            { fields: ['user_id'], unique: true },
            { fields: ['role_id'] },
            { fields: ['status'] }
        ]
    });

    return SystemUser;
};