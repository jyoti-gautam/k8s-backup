import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const User = sequelize.define('User', {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true
        },
        uuid: {
            type: DataTypes.CHAR(36),
            allowNull: false,
            unique: true,
            comment: 'Public identifier'
        },
        name: {
            type: DataTypes.STRING(150),
            allowNull: false
        },
        email: {
            type: DataTypes.STRING(190),
            allowNull: false,
            unique: true,
            validate: {
                isEmail: true
            }
        },
        emailVerifiedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'email_verified_at'
        },
        passwordHash: {
            type: DataTypes.STRING(255),
            allowNull: false,
            field: 'password_hash'
        },
        avatarUrl: {
            type: DataTypes.STRING(500),
            allowNull: true,
            field: 'avatar_url'
        },
        timezone: {
            type: DataTypes.STRING(50),
            defaultValue: 'UTC'
        },
        locale: {
            type: DataTypes.STRING(10),
            defaultValue: 'en'
        },
        phone: {
            type: DataTypes.STRING(20),
            allowNull: true
        },
        phoneVerifiedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'phone_verified_at'
        },
        status: {
            type: DataTypes.ENUM('active', 'blocked', 'deleted', 'pending_verification'),
            defaultValue: 'pending_verification'
        },
        lastLoginAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'last_login_at'
        },
        lastLoginIp: {
            type: DataTypes.STRING(45),
            allowNull: true,
            field: 'last_login_ip'
        },
        failedLoginAttempts: {
            type: DataTypes.INTEGER.UNSIGNED,
            defaultValue: 0,
            field: 'failed_login_attempts'
        },
        lockedUntil: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'locked_until'
        },
        // Password reset fields
        passwordResetTokenHash: {
            type: DataTypes.STRING(255),
            allowNull: true,
            field: 'password_reset_token_hash'
        },
        passwordResetExpiresAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'password_reset_expires_at'
        },
        passwordResetUsedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'password_reset_used_at'
        },
        // Email verification fields
        emailVerificationTokenHash: {
            type: DataTypes.STRING(255),
            allowNull: true,
            field: 'email_verification_token_hash'
        },
        emailVerificationExpiresAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'email_verification_expires_at'
        },
        emailVerificationEmail: {
            type: DataTypes.STRING(190),
            allowNull: true,
            field: 'email_verification_email'
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW,
            field: 'created_at'
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW,
            field: 'updated_at'
        },
        deletedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'deleted_at'
        },
        // Token fields
        accessToken: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'access_token'
        },
        refreshTokenHash: {
            type: DataTypes.STRING(255),
            allowNull: true,
            field: 'refresh_token_hash'
        },
        refreshTokenExpiresAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'refresh_token_expires_at'
        },
    }, {
        tableName: 'users',
        timestamps: true,
        underscored: true,
        paranoid: true,
        indexes: [
            { fields: ['email'] },
            { fields: ['status'] },
            { fields: ['created_at'] },
            { fields: ['uuid'] },
            { fields: ['password_reset_token_hash'] },
            { fields: ['email_verification_token_hash'] }
        ]
    });

    return User;
};