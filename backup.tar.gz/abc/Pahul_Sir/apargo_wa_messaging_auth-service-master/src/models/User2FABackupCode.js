import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const User2FABackupCode = sequelize.define('User2FABackupCode', {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true
        },
        userId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
            field: 'user_id'
        },
        codeHash: {
            type: DataTypes.STRING(255),
            allowNull: false,
            field: 'code_hash'
        },
        usedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'used_at'
        },
        usedIp: {
            type: DataTypes.STRING(45),
            allowNull: true,
            field: 'used_ip'
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW,
            field: 'created_at'
        }
    }, {
        tableName: 'user_2fa_backup_codes',
        timestamps: false,
        indexes: [
            { fields: ['user_id'] }
        ]
    });

    return User2FABackupCode;
};