import bcrypt from 'bcryptjs';
import 'dotenv/config';
import { v4 as uuidv4 } from 'uuid';
import { initModels } from '../models/index.js';

// =========================
// HELPER: Look up Role ID
// =========================
const getRoleId = async (Role, slug, scope) => {
    const role = await Role.findOne({
        where: { slug, scope, organizationId: null, projectId: null }
    });
    if (!role) throw new Error(`Role not found: slug="${slug}" scope="${scope}"`);
    return role.id;
};

// =========================
// SEED ROLES
// =========================
const seedRoles = async (Role) => {
    console.log('\n🌱 Seeding Roles...\n');

    const roles = [
        // SYSTEM ROLES
        { name: 'System Admin', slug: 'system-admin', description: 'Super administrator with full system-wide access and control.', scope: 'system' },
        { name: 'System Manager', slug: 'system-manager', description: 'Manages system-wide configurations and operations.', scope: 'system' },
        { name: 'System Support', slug: 'system-support', description: 'Handles system-level support and troubleshooting tasks.', scope: 'system' },

        // ORGANIZATION ROLES
        { name: 'Owner', slug: 'owner', description: 'Organization owner with full control over the organization.', scope: 'organization' },
        { name: 'Admin', slug: 'admin', description: 'Organization administrator managing members and settings.', scope: 'organization' },
        { name: 'Customer', slug: 'customer', description: 'Customer account within an organization.', scope: 'organization' },
        { name: 'Reseller', slug: 'reseller', description: 'Reseller managing multiple customers within the organization.', scope: 'organization' },
        { name: 'Project User', slug: 'project-user', description: 'Standard organization member assigned to projects.', scope: 'organization' },

        // PROJECT ROLES
        { name: 'Admin', slug: 'admin', description: 'Full control over the project.', scope: 'project' },
        { name: 'Member', slug: 'member', description: 'Standard project member.', scope: 'project' },
        { name: 'Agent', slug: 'agent', description: 'Handles operational tasks inside the project.', scope: 'project' }
    ];

    for (const roleData of roles) {
        const [role, created] = await Role.findOrCreate({
            where: {
                slug: roleData.slug,
                scope: roleData.scope,
                organizationId: null,
                projectId: null
            },
            defaults: {
                uuid: uuidv4(),
                name: roleData.name,
                slug: roleData.slug,
                description: roleData.description,
                scope: roleData.scope,
                organizationId: null,
                projectId: null,
                createdBy: null,
                isDefault: true,
                isSystem: true,
                status: 'active'
            }
        });

        console.log(created
            ? `✓ Created  [${role.scope}] role: ${role.name} (ID: ${role.id})`
            : `↻ Exists   [${role.scope}] role: ${role.name} (ID: ${role.id})`
        );
    }
};

// =========================
// SEED SYSTEM USERS
// =========================
const seedSystemUsers = async (Role, User, SystemUser) => {
    console.log('\n🌱 Seeding System Users...\n');

    // Pre-fetch system role IDs once
    const roleIds = {
        admin: await getRoleId(Role, 'system-admin', 'system'),
        manager: await getRoleId(Role, 'system-manager', 'system'),
        support: await getRoleId(Role, 'system-support', 'system')
    };

    const systemUsersData = [
        { name: 'System Administrator 1', email: 'systemadmin1@aigreentick.com', password: 'SystemAdmin1@123', roleKey: 'admin' },
        { name: 'System Administrator 2', email: 'systemadmin2@aigreentick.com', password: 'SystemAdmin2@123', roleKey: 'admin' },
        { name: 'System Manager 1', email: 'systemmanager1@aigreentick.com', password: 'SystemManager1@123', roleKey: 'manager' },
        { name: 'System Manager 2', email: 'systemmanager2@aigreentick.com', password: 'SystemManager2@123', roleKey: 'manager' },
        { name: 'System Support 1', email: 'systemsupport1@aigreentick.com', password: 'SystemSupport1@123', roleKey: 'support' },
        { name: 'System Support 2', email: 'systemsupport2@aigreentick.com', password: 'SystemSupport2@123', roleKey: 'support' }
    ];

    for (const sysUser of systemUsersData) {
        const passwordHash = await bcrypt.hash(sysUser.password, 10);

        const [user, userCreated] = await User.findOrCreate({
            where: { email: sysUser.email },
            defaults: {
                uuid: uuidv4(),
                name: sysUser.name,
                email: sysUser.email,
                passwordHash,
                status: 'active',
                emailVerifiedAt: new Date()
            }
        });

        const [systemUser, systemCreated] = await SystemUser.findOrCreate({
            where: { userId: user.id },
            defaults: {
                userId: user.id,
                roleId: roleIds[sysUser.roleKey],   // ← FK role ID
                status: 'active',
                assignedAt: new Date(),
                assignedBy: null
            }
        });

        console.log(
            `✓ [${sysUser.roleKey.padEnd(7)}] UserID: ${user.id} | SystemUserID: ${systemUser.id} | RoleID: ${roleIds[sysUser.roleKey]} | Email: ${user.email} | Created: ${userCreated}`
        );
    }
};

// =========================
// SEED ORGANIZATIONS
// =========================
const seedOrganizations = async (Role, User, Organization, OrganizationUser) => {
    console.log('\n🌱 Seeding Organizations...\n');

    // Pre-fetch org role IDs once
    const roleIds = {
        owner: await getRoleId(Role, 'owner', 'organization'),
        admin: await getRoleId(Role, 'admin', 'organization'),
        reseller: await getRoleId(Role, 'reseller', 'organization'),
        customer: await getRoleId(Role, 'customer', 'organization'),
        projectUser: await getRoleId(Role, 'project-user', 'organization')
    };

    const organizationsData = [
        {
            name: 'Aigreentick Solutions',
            slug: 'aigreentick-solutions',
            displayName: 'Aigreentick Solutions',
            ownerName: 'John Doe',
            ownerEmail: 'owner1@aigreentick.com',
            ownerPassword: 'Owner1@123'
        },
        {
            name: 'TechCorp Innovations',
            slug: 'techcorp-innovations',
            displayName: 'TechCorp Innovations',
            ownerName: 'Jane Smith',
            ownerEmail: 'owner2@techcorp.com',
            ownerPassword: 'Owner2@123'
        }
    ];

    for (const orgData of organizationsData) {

        // --- Owner ---
        const ownerPasswordHash = await bcrypt.hash(orgData.ownerPassword, 10);
        const [ownerUser, ownerCreated] = await User.findOrCreate({
            where: { email: orgData.ownerEmail },
            defaults: {
                uuid: uuidv4(),
                name: orgData.ownerName,
                email: orgData.ownerEmail,
                passwordHash: ownerPasswordHash,
                status: 'active',
                emailVerifiedAt: new Date()
            }
        });
        console.log(`✓ [owner]       UserID: ${ownerUser.id} | Email: ${ownerUser.email} | Created: ${ownerCreated}`);

        // --- Organization ---
        const [organization, orgCreated] = await Organization.findOrCreate({
            where: { slug: orgData.slug },
            defaults: {
                uuid: uuidv4(),
                slug: orgData.slug,
                name: orgData.name,
                displayName: orgData.displayName,
                organizationType: 'organization',
                ownerUserId: ownerUser.id,
                status: 'active'
            }
        });
        console.log(`✓ [org]         OrgID: ${organization.id} | Name: ${organization.name} | Created: ${orgCreated}`);

        // --- Owner → OrganizationUser ---
        const [ownerOrgUser, ownerLinkCreated] = await OrganizationUser.findOrCreate({
            where: { userId: ownerUser.id, organizationId: organization.id },
            defaults: {
                roleId: roleIds.owner,              // ← FK role ID
                status: 'active',
                joinedAt: new Date()
            }
        });
        console.log(
            `✓ [owner]       OrgUserID: ${ownerOrgUser.id} | UserID: ${ownerUser.id} | OrgID: ${organization.id} | RoleID: ${roleIds.owner} | Created: ${ownerLinkCreated}`
        );

        // --- Org Admin ---
        const adminPasswordHash = await bcrypt.hash('Admin@123', 10);
        const [orgAdminUser, adminCreated] = await User.findOrCreate({
            where: { email: `admin@${orgData.slug}.com` },
            defaults: {
                uuid: uuidv4(),
                name: `Admin - ${organization.name}`,
                email: `admin@${orgData.slug}.com`,
                passwordHash: adminPasswordHash,
                status: 'active',
                emailVerifiedAt: new Date()
            }
        });
        const [adminOrgUser, adminLinkCreated] = await OrganizationUser.findOrCreate({
            where: { userId: orgAdminUser.id, organizationId: organization.id },
            defaults: {
                roleId: roleIds.admin,              // ← FK role ID
                status: 'active',
                joinedAt: new Date()
            }
        });
        console.log(
            `✓ [admin]       UserID: ${orgAdminUser.id} | OrgUserID: ${adminOrgUser.id} | OrgID: ${organization.id} | RoleID: ${roleIds.admin} | Created: ${adminCreated}`
        );

        // --- Resellers ---
        for (let i = 1; i <= 2; i++) {
            const resellerPasswordHash = await bcrypt.hash(`Reseller${i}@123`, 10);
            const [resellerUser, resellerCreated] = await User.findOrCreate({
                where: { email: `reseller${i}@${orgData.slug}.com` },
                defaults: {
                    uuid: uuidv4(),
                    name: `Reseller ${i} - ${organization.name}`,
                    email: `reseller${i}@${orgData.slug}.com`,
                    passwordHash: resellerPasswordHash,
                    status: 'active',
                    emailVerifiedAt: new Date()
                }
            });
            const [resellerOrgUser, resellerLinkCreated] = await OrganizationUser.findOrCreate({
                where: { userId: resellerUser.id, organizationId: organization.id },
                defaults: {
                    roleId: roleIds.reseller,       // ← FK role ID
                    status: 'active',
                    joinedAt: new Date()
                }
            });
            console.log(
                `✓ [reseller]    UserID: ${resellerUser.id} | OrgUserID: ${resellerOrgUser.id} | OrgID: ${organization.id} | RoleID: ${roleIds.reseller} | Created: ${resellerCreated}`
            );
        }

        // --- Customers ---
        for (let i = 1; i <= 5; i++) {
            const customerPasswordHash = await bcrypt.hash(`Customer${i}@123`, 10);
            const [customerUser, customerCreated] = await User.findOrCreate({
                where: { email: `customer${i}@${orgData.slug}.com` },
                defaults: {
                    uuid: uuidv4(),
                    name: `Customer ${i} - ${organization.name}`,
                    email: `customer${i}@${orgData.slug}.com`,
                    passwordHash: customerPasswordHash,
                    status: 'active',
                    emailVerifiedAt: new Date()
                }
            });
            const [customerOrgUser, customerLinkCreated] = await OrganizationUser.findOrCreate({
                where: { userId: customerUser.id, organizationId: organization.id },
                defaults: {
                    roleId: roleIds.customer,       // ← FK role ID
                    status: 'active',
                    joinedAt: new Date()
                }
            });
            console.log(
                `✓ [customer]    UserID: ${customerUser.id} | OrgUserID: ${customerOrgUser.id} | OrgID: ${organization.id} | RoleID: ${roleIds.customer} | Created: ${customerLinkCreated}`
            );
        }

        // --- Project Users ---
        for (let i = 1; i <= 3; i++) {
            const projectUserPasswordHash = await bcrypt.hash(`ProjectUser${i}@123`, 10);
            const [projectUser, projectUserCreated] = await User.findOrCreate({
                where: { email: `projectuser${i}@${orgData.slug}.com` },
                defaults: {
                    uuid: uuidv4(),
                    name: `Project User ${i} - ${organization.name}`,
                    email: `projectuser${i}@${orgData.slug}.com`,
                    passwordHash: projectUserPasswordHash,
                    status: 'active',
                    emailVerifiedAt: new Date()
                }
            });
            const [projectOrgUser, projectUserLinkCreated] = await OrganizationUser.findOrCreate({
                where: { userId: projectUser.id, organizationId: organization.id },
                defaults: {
                    roleId: roleIds.projectUser,    // ← FK role ID
                    status: 'active',
                    joinedAt: new Date()
                }
            });
            console.log(
                `✓ [project-user] UserID: ${projectUser.id} | OrgUserID: ${projectOrgUser.id} | OrgID: ${organization.id} | RoleID: ${roleIds.projectUser} | Created: ${projectUserLinkCreated}`
            );
        }
    }
};

// =========================
// MAIN
// =========================
const seedAll = async () => {
    try {
        console.log('🌱 Initializing models...');
        const { User, Organization, OrganizationUser, SystemUser, Role } = await initModels();

        await seedRoles(Role);
        await seedSystemUsers(Role, User, SystemUser);
        await seedOrganizations(Role, User, Organization, OrganizationUser);

        console.log('\n✅ All seeding completed successfully!\n');
        process.exit(0);
    } catch (error) {
        console.error('❌ Error seeding data:', error);
        process.exit(1);
    }
};

seedAll();

/*
🌱 Initializing models...
🌱 Seeding Roles...
✓ Created  [system] role: System Admin (ID: 1)
✓ Created  [system] role: System Manager (ID: 2)
✓ Created  [system] role: System Support (ID: 3)
✓ Created  [organization] role: Owner (ID: 4)
✓ Created  [organization] role: Admin (ID: 5)
✓ Created  [organization] role: Customer (ID: 6)
✓ Created  [organization] role: Reseller (ID: 7)
✓ Created  [organization] role: Project User (ID: 8)
✓ Created  [project] role: Admin (ID: 9)
✓ Created  [project] role: Member (ID: 10)
✓ Created  [project] role: Agent (ID: 11)

🌱 Seeding System Users...

✓ [admin  ] UserID: 1 | SystemUserID: 1 | RoleID: 1 | Email: systemadmin1@aigreentick.com | Created: true
✓ [admin  ] UserID: 2 | SystemUserID: 2 | RoleID: 1 | Email: systemadmin2@aigreentick.com | Created: true
✓ [manager] UserID: 3 | SystemUserID: 3 | RoleID: 2 | Email: systemmanager1@aigreentick.com | Created: true
✓ [manager] UserID: 4 | SystemUserID: 4 | RoleID: 2 | Email: systemmanager2@aigreentick.com | Created: true
✓ [support] UserID: 5 | SystemUserID: 5 | RoleID: 3 | Email: systemsupport1@aigreentick.com | Created: true
✓ [support] UserID: 6 | SystemUserID: 6 | RoleID: 3 | Email: systemsupport2@aigreentick.com | Created: true

🌱 Seeding Organizations...

✓ [owner]       UserID: 7 | Email: owner1@aigreentick.com | Created: true
✓ [org]         OrgID: 1 | Name: Aigreentick Solutions | Created: true
✓ [owner]       OrgUserID: 1 | UserID: 7 | OrgID: 1 | RoleID: 4 | Created: true
✓ [admin]       UserID: 8 | OrgUserID: 2 | OrgID: 1 | RoleID: 5 | Created: true
✓ [reseller]    UserID: 9 | OrgUserID: 3 | OrgID: 1 | RoleID: 7 | Created: true
✓ [reseller]    UserID: 10 | OrgUserID: 4 | OrgID: 1 | RoleID: 7 | Created: true
✓ [customer]    UserID: 11 | OrgUserID: 5 | OrgID: 1 | RoleID: 6 | Created: true
✓ [customer]    UserID: 12 | OrgUserID: 6 | OrgID: 1 | RoleID: 6 | Created: true
✓ [customer]    UserID: 13 | OrgUserID: 7 | OrgID: 1 | RoleID: 6 | Created: true
✓ [customer]    UserID: 14 | OrgUserID: 8 | OrgID: 1 | RoleID: 6 | Created: true
✓ [customer]    UserID: 15 | OrgUserID: 9 | OrgID: 1 | RoleID: 6 | Created: true
✓ [project-user] UserID: 16 | OrgUserID: 10 | OrgID: 1 | RoleID: 8 | Created: true
✓ [project-user] UserID: 17 | OrgUserID: 11 | OrgID: 1 | RoleID: 8 | Created: true
✓ [project-user] UserID: 18 | OrgUserID: 12 | OrgID: 1 | RoleID: 8 | Created: true
✓ [owner]       UserID: 19 | Email: owner2@techcorp.com | Created: true
✓ [org]         OrgID: 2 | Name: TechCorp Innovations | Created: true
✓ [owner]       OrgUserID: 13 | UserID: 19 | OrgID: 2 | RoleID: 4 | Created: true
✓ [admin]       UserID: 20 | OrgUserID: 14 | OrgID: 2 | RoleID: 5 | Created: true
✓ [reseller]    UserID: 21 | OrgUserID: 15 | OrgID: 2 | RoleID: 7 | Created: true
✓ [reseller]    UserID: 22 | OrgUserID: 16 | OrgID: 2 | RoleID: 7 | Created: true
✓ [customer]    UserID: 23 | OrgUserID: 17 | OrgID: 2 | RoleID: 6 | Created: true
✓ [customer]    UserID: 24 | OrgUserID: 18 | OrgID: 2 | RoleID: 6 | Created: true
✓ [customer]    UserID: 25 | OrgUserID: 19 | OrgID: 2 | RoleID: 6 | Created: true
✓ [customer]    UserID: 26 | OrgUserID: 20 | OrgID: 2 | RoleID: 6 | Created: true
✓ [customer]    UserID: 27 | OrgUserID: 21 | OrgID: 2 | RoleID: 6 | Created: true
✓ [project-user] UserID: 28 | OrgUserID: 22 | OrgID: 2 | RoleID: 8 | Created: true
✓ [project-user] UserID: 29 | OrgUserID: 23 | OrgID: 2 | RoleID: 8 | Created: true
✓ [project-user] UserID: 30 | OrgUserID: 24 | OrgID: 2 | RoleID: 8 | Created: true

✅ All seeding completed successfully!
*/