import { body } from 'express-validator';

export const validateRegister = [
    body('name')
        .trim()
        .notEmpty()
        .withMessage('Name is required')
        .isLength({ min: 2, max: 150 })
        .withMessage('Name must be between 2 and 150 characters'),

    body('email')
        .trim()
        .notEmpty()
        .withMessage('Email is required')
        .isEmail()
        .withMessage('Invalid email format')
        .normalizeEmail(),

    body('password')
        .notEmpty()
        .withMessage('Password is required')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
        .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number'),

    body('phone')
        .optional()
        .matches(/^\+?[1-9]\d{1,14}$/)
        .withMessage('Invalid phone number format'),

    body('timezone')
        .optional()
        .isString(),

    body('locale')
        .optional()
        .isString()
        .isLength({ max: 10 })
];

export const validateLogin = [
    body('email')
        .trim()
        .notEmpty()
        .withMessage('Email is required')
        .isEmail()
        .withMessage('Invalid email format')
        .normalizeEmail(),

    body('password')
        .notEmpty()
        .withMessage('Password is required'),

    body('deviceName')
        .optional()
        .isString()
        .isLength({ max: 255 }),

    body('twoFactorToken')
        .optional()
        .isString()
        .isLength({ min: 6, max: 8 })
];

export const validate2FAToken = [
    body('token')
        .notEmpty()
        .withMessage('2FA token is required')
        .isString()
        .isLength({ min: 6, max: 8 })
        .withMessage('Invalid token format')
];

export const validatePassword = [
    body('password')
        .notEmpty()
        .withMessage('Password is required')
];

export const validatePasswordChange = [
    body('currentPassword')
        .notEmpty()
        .withMessage('Current password is required'),

    body('newPassword')
        .notEmpty()
        .withMessage('New password is required')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
        .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number')
];

export const validateEmail = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Valid email is required')
];

export const validatePasswordReset = [
    body('password')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters'),
    body('confirmPassword')
        .custom((value, { req }) => value === req.body.password)
        .withMessage('Passwords do not match')
];

export const validateProfileUpdate = [
    body('name')
        .optional()
        .trim()
        .isLength({ min: 2 })
        .withMessage('Name must be at least 2 characters'),
    body('phone')
        .optional()
        .matches(/^\+?[1-9]\d{1,14}$/)
        .withMessage('Valid phone number required'),
    body('timezone')
        .optional()
        .isString()
        .withMessage('Valid timezone required'),
    body('locale')
        .optional()
        .isString()
        .withMessage('Valid locale required')
];

export const validateUserStatus = [
    body('status')
        .isIn(['active', 'blocked', 'deleted', 'pending_verification'])
        .withMessage('Invalid status value')
];

export const validateAdminCreateUser = [
    body('name')
        .trim()
        .notEmpty()
        .withMessage('Name is required')
        .isLength({ min: 2, max: 150 })
        .withMessage('Name must be between 2 and 150 characters'),

    body('email')
        .trim()
        .notEmpty()
        .withMessage('Email is required')
        .isEmail()
        .withMessage('Invalid email format')
        .normalizeEmail(),

    body('password')
        .notEmpty()
        .withMessage('Password is required')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
        .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number'),

    body('roleId')
        .notEmpty()
        .withMessage('Role ID is required')
        .isInt({ min: 1 })
        .withMessage('Valid role ID is required'),

    body('organizationId')
        .optional()
        .isInt({ min: 1 })
        .withMessage('Organization ID must be a valid integer'),

    body('phone')
        .optional()
        .matches(/^\+?[1-9]\d{1,14}$/)
        .withMessage('Invalid phone number format'),

    body('timezone')
        .optional()
        .isString()
        .isLength({ max: 50 }),

    body('locale')
        .optional()
        .isString()
        .isLength({ max: 10 })
];

export const validateSystemUserCreate = [
    body('userId')
        .notEmpty()
        .withMessage('User ID is required')
        .isInt({ min: 1 })
        .withMessage('Valid user ID is required'),

    body('systemRole')
        .notEmpty()
        .withMessage('System role is required')
        .isIn(['admin', 'user', 'support'])
        .withMessage('Invalid system role. Must be admin, user, or support')
];

export const validateSystemUserUpdate = [
    body('systemRole')
        .optional()
        .isIn(['admin', 'user', 'support'])
        .withMessage('Invalid system role. Must be admin, user, or support'),

    body('status')
        .optional()
        .isIn(['active', 'removed'])
        .withMessage('Invalid status. Must be active or removed')
];