import { validationResult } from 'express-validator';
import authService from '../services/auth.service.js';
import ApiResponse from '../utils/ApiResponse.js';

class AuthController {
    async createUserByAdmin(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }
            const allowedRoles = ['owner', 'admin'];
            if (!allowedRoles.includes(req.user.organizationRole)) {
                return ApiResponse.forbidden(res, 'Only admins can create users');
            }
            const { name, email, password, phone, timezone, locale, organizationId, organizationRoleSlug } = req.body;
            const result = await authService.createUserByAdmin({
                name, email, password, phone, timezone, locale,
                organizationId,
                organizationRoleSlug,   // ← was organizationRole
                createdBy: req.user.userId
            });
            return ApiResponse.created(res, result, 'User created successfully by admin');
        } catch (error) {
            if (error.message.includes('already exists')) {
                return ApiResponse.conflict(res, error.message);
            }
            next(error);
        }
    }

    async updateUserStatus(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const { userId } = req.params;
            const { status } = req.body;
            const adminId = req.user.userId;

            await authService.updateUserStatus(userId, status, adminId);
            return ApiResponse.success(res, null, 'User status updated');
        } catch (error) {
            next(error);
        }
    }

    async unlockUserAccount(req, res, next) {
        try {
            const { userId } = req.params;
            const adminId = req.user.userId;

            await authService.unlockUserAccount(userId, adminId);
            return ApiResponse.success(res, null, 'User account unlocked');
        } catch (error) {
            next(error);
        }
    }

    async register(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const { name, email, password, phone, timezone, locale, organizationId } = req.body;

            const result = await authService.register({
                name,
                email,
                password,
                phone,
                timezone,
                locale,
                organizationId
            });

            return ApiResponse.created(res, result, 'User registered successfully');
        } catch (error) {
            if (error.message.includes('already exists')) {
                return ApiResponse.conflict(res, error.message);
            }
            next(error);
        }
    }

    async login(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const { email, password, deviceName, twoFactorToken } = req.body;
            const ipAddress = req.ip || req.connection.remoteAddress;
            const userAgent = req.headers['user-agent'];

            const result = await authService.login({
                email,
                password,
                deviceName,
                ipAddress,
                userAgent,
                twoFactorToken
            });

            // If 2FA is required
            if (result.requires2FA) {
                return ApiResponse.success(res, result, result.message, 200);
            }

            return ApiResponse.success(res, result, 'Login successful');
        } catch (error) {
            if (error.message.includes('Invalid credentials') ||
                error.message.includes('not found') ||
                error.message.includes('locked') ||
                error.message.includes('Invalid 2FA')) {
                return ApiResponse.unauthorized(res, error.message);
            }
            next(error);
        }
    }

    async refreshToken(req, res, next) {
        try {
            const { refreshToken } = req.body;

            if (!refreshToken) {
                return ApiResponse.error(res, 'Refresh token is required', 400);
            }

            const result = await authService.refreshToken(refreshToken);
            return ApiResponse.success(res, result, 'Token refreshed successfully');
        } catch (error) {
            return ApiResponse.unauthorized(res, error.message);
        }
    }

    async logout(req, res, next) {
        try {
            const authHeader = req.headers.authorization;
            const token = authHeader.substring(7);

            await authService.logout(token, req.user.userId);
            return ApiResponse.success(res, null, 'Logged out successfully');
        } catch (error) {
            next(error);
        }
    }

    async verifyEmail(req, res, next) {
        try {
            const { token } = req.params;

            await authService.verifyEmail(token);
            return ApiResponse.success(res, null, 'Email verified successfully');
        } catch (error) {
            if (error.message.includes('Invalid') || error.message.includes('expired')) {
                return ApiResponse.error(res, error.message, 400);
            }
            next(error);
        }
    }

    async getProfile(req, res, next) {
        try {
            const userId = req.user.userId;
            const profile = await authService.getProfile(userId);
            return ApiResponse.success(res, profile);
        } catch (error) {
            next(error);
        }
    }

    // 2FA Endpoints
    async setup2FA(req, res, next) {
        try {
            const userId = req.user.userId;
            const { method } = req.body;

            const result = await authService.setup2FA(userId, method);
            return ApiResponse.success(res, result, '2FA setup initiated');
        } catch (error) {
            next(error);
        }
    }

    async enable2FA(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const userId = req.user.userId;
            const { token } = req.body;

            const result = await authService.enable2FA(userId, token);
            return ApiResponse.success(res, result, '2FA enabled successfully');
        } catch (error) {
            if (error.message.includes('Invalid') || error.message.includes('already')) {
                return ApiResponse.error(res, error.message, 400);
            }
            next(error);
        }
    }

    async disable2FA(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const userId = req.user.userId;
            const { password } = req.body;

            const result = await authService.disable2FA(userId, password);
            return ApiResponse.success(res, result, '2FA disabled successfully');
        } catch (error) {
            if (error.message.includes('Invalid password')) {
                return ApiResponse.unauthorized(res, error.message);
            }
            if (error.message.includes('not enabled')) {
                return ApiResponse.error(res, error.message, 400);
            }
            next(error);
        }
    }

    async verify2FA(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const userId = req.user.userId;
            const { token } = req.body;
            const ipAddress = req.ip || req.connection.remoteAddress;

            const isValid = await authService.verify2FAToken(userId, token, ipAddress);

            if (isValid) {
                return ApiResponse.success(res, null, '2FA token verified successfully');
            } else {
                return ApiResponse.unauthorized(res, 'Invalid 2FA token');
            }
        } catch (error) {
            next(error);
        }
    }

    async regenerateBackupCodes(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const userId = req.user.userId;
            const { password } = req.body;

            const result = await authService.regenerateBackupCodes(userId, password);
            return ApiResponse.success(res, result, 'Backup codes regenerated');
        } catch (error) {
            if (error.message.includes('Invalid password')) {
                return ApiResponse.unauthorized(res, error.message);
            }
            next(error);
        }
    }

    async resendVerificationEmail(req, res, next) {
        try {
            const { email } = req.body;
            await authService.resendVerificationEmail(email);
            return ApiResponse.success(res, null, 'Verification email sent');
        } catch (error) {
            next(error);
        }
    }

    async forgotPassword(req, res, next) {
        try {
            const { email } = req.body;
            await authService.forgotPassword(email);
            return ApiResponse.success(res, null, 'Password reset email sent');
        } catch (error) {
            next(error);
        }
    }

    async resetPassword(req, res, next) {
        try {
            const { token } = req.params;
            const { password } = req.body;
            await authService.resetPassword(token, password);
            return ApiResponse.success(res, null, 'Password reset successfully');
        } catch (error) {
            if (error.message.includes('Invalid') || error.message.includes('expired')) {
                return ApiResponse.error(res, error.message, 400);
            }
            next(error);
        }
    }

    async changePassword(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const userId = req.user.userId;
            const { currentPassword, newPassword } = req.body;

            await authService.changePassword(userId, currentPassword, newPassword);
            return ApiResponse.success(res, null, 'Password changed successfully');
        } catch (error) {
            if (error.message.includes('Invalid password')) {
                return ApiResponse.unauthorized(res, error.message);
            }
            next(error);
        }
    }

    async updateProfile(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            const userId = req.user.userId;
            const updates = req.body;

            const profile = await authService.updateProfile(userId, updates);
            return ApiResponse.success(res, profile, 'Profile updated successfully');
        } catch (error) {
            next(error);
        }
    }

    async listSessions(req, res, next) {
        try {
            const userId = req.user.userId;
            const sessions = await authService.listSessions(userId);
            return ApiResponse.success(res, sessions);
        } catch (error) {
            next(error);
        }
    }

    async revokeSession(req, res, next) {
        try {
            const userId = req.user.userId;
            const { sessionId } = req.params;

            await authService.revokeSession(userId, sessionId);
            return ApiResponse.success(res, null, 'Session revoked successfully');
        } catch (error) {
            next(error);
        }
    }

    async revokeAllSessions(req, res, next) {
        try {
            const userId = req.user.userId;
            const authHeader = req.headers.authorization;
            const currentToken = authHeader.substring(7);

            await authService.revokeAllSessions(userId, currentToken);
            return ApiResponse.success(res, null, 'All other sessions revoked');
        } catch (error) {
            next(error);
        }
    }

    // controllers/auth.controller.js - Add these methods to your existing AuthController class

    async assignSystemRole(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            // Only system admins can assign system roles
            if (!req.user.systemRoleSlug || req.user.systemRoleSlug !== 'system-admin') {
                return ApiResponse.forbidden(res, 'Only system admins can assign system roles');
            }
            const { userId, systemRoleSlug } = req.body;
            const result = await authService.assignSystemRole({ userId, systemRoleSlug }, req.user.userId);

            return ApiResponse.created(res, result, 'System role assigned successfully');
        } catch (error) {
            if (error.message.includes('already has')) {
                return ApiResponse.conflict(res, error.message);
            }
            if (error.message.includes('not found')) {
                return ApiResponse.notFound(res, error.message);
            }
            next(error);
        }
    }

    async updateSystemRole(req, res, next) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return ApiResponse.validationError(res, errors.array());
            }

            // Only system admins can update system roles
            if (!req.user.systemRole || req.user.systemRole !== 'admin') {
                return ApiResponse.forbidden(res, 'Only system admins can update system roles');
            }

            const { userId } = req.params;
            const updates = req.body;

            const result = await authService.updateSystemRole(
                userId,
                updates,
                req.user.userId
            );

            return ApiResponse.success(res, result, 'System role updated successfully');
        } catch (error) {
            if (error.message.includes('not found')) {
                return ApiResponse.notFound(res, error.message);
            }
            next(error);
        }
    }

    async removeSystemRole(req, res, next) {
        try {
            // Only system admins can remove system roles
            if (!req.user.systemRole || req.user.systemRole !== 'admin') {
                return ApiResponse.forbidden(res, 'Only system admins can remove system roles');
            }

            const { userId } = req.params;

            await authService.removeSystemRole(userId, req.user.userId);

            return ApiResponse.success(res, null, 'System role removed successfully');
        } catch (error) {
            if (error.message.includes('not found')) {
                return ApiResponse.notFound(res, error.message);
            }
            next(error);
        }
    }

    async listSystemUsers(req, res, next) {
        try {
            // Only system users can list system users
            if (!req.user.systemRole) {
                return ApiResponse.forbidden(res, 'Access denied');
            }

            const { roleSlug, status } = req.query;
            const users = await authService.listSystemUsers({ roleSlug, status });

            return ApiResponse.success(res, users);
        } catch (error) {
            next(error);
        }
    }
}



export default new AuthController();