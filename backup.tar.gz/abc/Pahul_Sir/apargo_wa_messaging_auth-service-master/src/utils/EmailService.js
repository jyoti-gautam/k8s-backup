import nodemailer from 'nodemailer';

class EmailService {

    static transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true, // ✅ MUST be true for 465
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
        }
    });


    static async sendOTP(email, otp) {
        await this.transporter.sendMail({
            from: `"Security Team" <${process.env.SMTP_FROM}>`,
            to: email,
            subject: 'Your Login OTP Code',
            html: `
                <h2>Your Verification Code</h2>
                <p>Your OTP is:</p>
                <h1>${otp}</h1>
                <p>This code expires in 5 minutes.</p>
            `
        });
    }

    static async sendEmailVerification(email, token, link) {
        await this.transporter.sendMail({
            from: `"Security Team" <${process.env.SMTP_FROM}>`,
            to: email,
            subject: 'Verify Your Email',
            html: `
            <h2>Email Verification</h2>
            <p>Click the link below to verify your account:</p>
            <a href="${link}">${link}</a>
            <p>This link expires in 24 hours.</p>
        `
        });
    }
}

export default EmailService;
