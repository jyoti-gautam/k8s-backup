class ApiResponse {
    static success(res, data = null, message = "Success", statusCode = 200) {
        return res.status(statusCode).json({
            success: true,
            message,
            data
        });
    }

    static created(res, data = null, message = "Resource created") {
        return res.status(201).json({
            success: true,
            message,
            data
        });
    }

    static error(res, message = "Something went wrong", statusCode = 500) {
        return res.status(statusCode).json({
            success: false,
            message
        });
    }

    static unauthorized(res, message = "Unauthorized") {
        return res.status(401).json({
            success: false,
            message
        });
    }

    static forbidden(res, message = "Forbidden") {
        return res.status(403).json({
            success: false,
            message
        });
    }

    static notFound(res, message = "Resource not found") {
        return res.status(404).json({
            success: false,
            message
        });
    }

    static conflict(res, message = "Conflict") {
        return res.status(409).json({
            success: false,
            message
        });
    }

    static validationError(res, errors = []) {
        return res.status(422).json({
            success: false,
            message: "Validation failed",
            errors
        });
    }
}

export default ApiResponse;
