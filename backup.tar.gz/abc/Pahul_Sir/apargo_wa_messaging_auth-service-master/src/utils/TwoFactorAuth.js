import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import QRCode from 'qrcode';
import speakeasy from 'speakeasy';

class TwoFactorAuth {
    /**
     * Generate TOTP secret for a user
     */
    static generateSecret(userEmail) {
        const secret = speakeasy.generateSecret({
            name: `${process.env.APP_NAME || 'APARGO'} (${userEmail})`,
            length: 32
        });

        return {
            secret: secret.base32,
            otpauthUrl: secret.otpauth_url
        };
    }

    /**
     * Generate QR code for TOTP setup
     */
    static async generateQRCode(otpauthUrl) {
        try {
            const qrCode = await QRCode.toDataURL(otpauthUrl);
            return qrCode;
        } catch (error) {
            throw new Error('Failed to generate QR code');
        }
    }

    /**
     * Verify TOTP token
     */
    static verifyToken(secret, token) {
        return speakeasy.totp.verify({
            secret,
            encoding: 'base32',
            token,
            window: parseInt(process.env.TOTP_WINDOW) || 1
        });
    }

    /**
     * Generate backup codes
     */
    static generateBackupCodes(count = 10) {
        const codes = [];
        for (let i = 0; i < count; i++) {
            // Generate 8-character alphanumeric code
            const code = crypto.randomBytes(4).toString('hex').toUpperCase();
            codes.push(code);
        }
        return codes;
    }

    /**
     * Hash backup code
     */
    static async hashBackupCode(code) {
        const salt = await bcrypt.genSalt(10);
        return await bcrypt.hash(code, salt);
    }

    /**
     * Verify backup code
     */
    static async verifyBackupCode(code, hash) {
        return await bcrypt.compare(code, hash);
    }

    /**
     * Encrypt secret (simple base64 for now - use proper encryption in production)
     */
    static encryptSecret(secret) {
        // In production, use proper encryption with a key
        // For now, we'll use base64 encoding
        return Buffer.from(secret).toString('base64');
    }

    /**
     * Decrypt secret
     */
    static decryptSecret(encryptedSecret) {
        // In production, use proper decryption
        return Buffer.from(encryptedSecret, 'base64').toString('utf-8');
    }
}

export default TwoFactorAuth;