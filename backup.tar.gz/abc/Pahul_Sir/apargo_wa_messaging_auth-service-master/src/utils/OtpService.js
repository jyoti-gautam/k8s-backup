import crypto from 'crypto';
import bcrypt from 'bcryptjs';

class OtpService {
    generateOTP(length = 6) {
        const digits = '0123456789';
        let otp = '';
        for (let i = 0; i < length; i++) {
            otp += digits[Math.floor(Math.random() * digits.length)];
        }
        return otp;
    }

    async hashOTP(otp) {
        return bcrypt.hash(otp, 10);
    }

    async verifyOTP(otp, hash) {
        return bcrypt.compare(otp, hash);
    }
}

export default new OtpService();